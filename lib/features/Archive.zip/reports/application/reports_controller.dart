import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../domain/medical_report.dart';

/// Holds the patient's report library in memory.
///
/// Starts empty. New reports are added when the user actually uploads one
/// from the Reports tab; the "Processing" state auto-flips to "Analysed"
/// after a brief delay (in production this is driven by the backend SSE
/// event from the AI pipeline).
class ReportsController extends Notifier<List<MedicalReport>> {
  @override
  List<MedicalReport> build() => const [];

  void addUpload({
    required String title,
    required ReportType type,
    required String fileRef,
  }) {
    final id = 'r_${DateTime.now().microsecondsSinceEpoch}';
    final report = MedicalReport(
      id: id,
      type: type,
      title: title,
      uploadedAt: DateTime.now(),
      status: ReportStatus.processing,
      fileRef: fileRef,
    );
    state = [report, ...state];

    // Mark as uploaded once the (simulated) handoff completes. Detailed
    // metric/finding extraction is produced by the backend AI pipeline —
    // until that's connected the report shows the uploaded document only.
    Timer(const Duration(seconds: 2), () {
      state = [
        for (final r in state)
          if (r.id == id)
            MedicalReport(
              id: r.id,
              type: r.type,
              title: r.title,
              uploadedAt: r.uploadedAt,
              status: ReportStatus.analyzed,
              fileRef: r.fileRef,
            )
          else
            r,
      ];
    });
  }

  void delete(String id) {
    state = state.where((r) => r.id != id).toList();
  }
}

final reportsControllerProvider =
    NotifierProvider<ReportsController, List<MedicalReport>>(
  ReportsController.new,
);
