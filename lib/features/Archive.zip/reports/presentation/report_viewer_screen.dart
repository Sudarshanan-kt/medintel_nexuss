import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

import '../../../app/router/route_names.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../shared/widgets/widgets.dart';
import '../application/reports_controller.dart';
import '../domain/medical_report.dart';

/// Report viewer — shows the real uploaded document plus its metadata.
///
/// Metric/finding extraction (key values, reference ranges, AI summary) is
/// produced server-side by the OCR + NLP pipeline. Until that backend is
/// connected the viewer renders the uploaded document and metadata only —
/// no fabricated lab values.
class ReportViewerScreen extends ConsumerWidget {
  const ReportViewerScreen({super.key, required this.reportId});
  final String reportId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final reports = ref.watch(reportsControllerProvider);
    MedicalReport? report;
    for (final r in reports) {
      if (r.id == reportId) {
        report = r;
        break;
      }
    }

    if (report == null) {
      return GradientScaffold(
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_rounded),
            onPressed: () => context.go(Routes.reports),
          ),
        ),
        body: EmptyState(
          icon: Icons.description_outlined,
          title: 'Report not found',
          message: 'This report was removed or never saved.',
          actionLabel: 'Back to reports',
          onAction: () => context.go(Routes.reports),
        ),
      );
    }

    return GradientScaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded),
          onPressed: () => context.go(Routes.reports),
        ),
        title: const Text('Report'),
        actions: [
          IconButton(
            icon: const Icon(Icons.delete_outline_rounded,
                color: AppColors.danger),
            onPressed: () async {
              ref.read(reportsControllerProvider.notifier).delete(reportId);
              if (context.mounted) context.go(Routes.reports);
            },
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(
          AppSpacing.gutter,
          AppSpacing.md,
          AppSpacing.gutter,
          120,
        ),
        children: [
          _DocumentImage(path: report.fileRef),
          const SizedBox(height: AppSpacing.lg),
          _MetaCard(report: report),
          const SizedBox(height: AppSpacing.lg),
          if (report.status == ReportStatus.processing)
            _NoticeCard(
              icon: Icons.hourglass_top_rounded,
              tone: PillTone.processing,
              title: 'Processing',
              body:
                  'Your report is being prepared. This will only take a moment.',
            )
          else
            _NoticeCard(
              icon: Icons.auto_awesome_rounded,
              tone: PillTone.info,
              title: 'AI analysis',
              body:
                  'Key values, reference ranges and findings are extracted by the MedIntel server pipeline. Connect the backend to populate this section automatically.',
            ),
        ],
      ),
    );
  }
}

class _DocumentImage extends StatelessWidget {
  const _DocumentImage({this.path});
  final String? path;

  @override
  Widget build(BuildContext context) {
    final file = path == null ? null : File(path!);
    final hasImage = file != null && file.existsSync();

    return ClipRRect(
      borderRadius: BorderRadius.circular(AppRadius.lg),
      child: AspectRatio(
        aspectRatio: 3 / 4,
        child: hasImage
            ? Image.file(file, fit: BoxFit.cover)
            : Container(
                color: AppColors.surfaceMuted,
                child: Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: const [
                      Icon(Icons.description_rounded,
                          size: 56, color: AppColors.textTertiary),
                      SizedBox(height: AppSpacing.sm),
                      Text(
                        'Document preview unavailable',
                        style: TextStyle(
                          color: AppColors.textTertiary,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
      ),
    );
  }
}

class _MetaCard extends StatelessWidget {
  const _MetaCard({required this.report});
  final MedicalReport report;

  @override
  Widget build(BuildContext context) {
    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            report.title,
            style: AppTypography.titleMd
                .copyWith(color: AppColors.textPrimary, fontSize: 17),
          ),
          const SizedBox(height: AppSpacing.md),
          _MetaRow(label: 'Type', value: report.typeLabel),
          const Divider(height: AppSpacing.lg),
          _MetaRow(
            label: 'Uploaded',
            value:
                DateFormat.yMMMd().add_jm().format(report.uploadedAt),
          ),
          const Divider(height: AppSpacing.lg),
          Row(
            children: [
              Text(
                'Status',
                style: AppTypography.bodyMd
                    .copyWith(color: AppColors.textSecondary),
              ),
              const Spacer(),
              StatusPill(
                label: report.status == ReportStatus.analyzed
                    ? 'Uploaded'
                    : 'Processing',
                tone: report.status == ReportStatus.analyzed
                    ? PillTone.success
                    : PillTone.processing,
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _MetaRow extends StatelessWidget {
  const _MetaRow({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Text(
          label,
          style: AppTypography.bodyMd
              .copyWith(color: AppColors.textSecondary),
        ),
        const Spacer(),
        Flexible(
          child: Text(
            value,
            textAlign: TextAlign.end,
            style: AppTypography.bodyMd.copyWith(
              color: AppColors.textPrimary,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ],
    );
  }
}

class _NoticeCard extends StatelessWidget {
  const _NoticeCard({
    required this.icon,
    required this.tone,
    required this.title,
    required this.body,
  });
  final IconData icon;
  final PillTone tone;
  final String title;
  final String body;

  @override
  Widget build(BuildContext context) {
    return AppCard(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: AppColors.tintBlue,
              borderRadius: BorderRadius.circular(AppRadius.sm),
            ),
            child: const Icon(Icons.auto_awesome_rounded,
                color: AppColors.primary, size: 20),
          ),
          const SizedBox(width: AppSpacing.md),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: AppTypography.bodyLg.copyWith(
                    color: AppColors.textPrimary,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  body,
                  style: AppTypography.bodyMd
                      .copyWith(color: AppColors.textSecondary, height: 1.5),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
