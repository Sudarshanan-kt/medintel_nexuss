import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';

import '../../../app/router/route_names.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../shared/widgets/widgets.dart';
import '../application/reports_controller.dart';
import '../domain/medical_report.dart';

class ReportsListScreen extends ConsumerWidget {
  const ReportsListScreen({super.key});

  Future<void> _showUploadSheet(BuildContext context, WidgetRef ref) async {
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(AppRadius.xl)),
      ),
      builder: (sheetContext) => _UploadSheet(
        onPicked: (source, type) async {
          Navigator.of(sheetContext).pop();
          await _pickAndUpload(context, ref, source: source, type: type);
        },
      ),
    );
  }

  Future<void> _pickAndUpload(
    BuildContext context,
    WidgetRef ref, {
    required ImageSource source,
    required ReportType type,
  }) async {
    try {
      final picker = ImagePicker();
      final file = await picker.pickImage(source: source, imageQuality: 85);
      if (file == null || !context.mounted) return;

      ref.read(reportsControllerProvider.notifier).addUpload(
            title: _suggestedTitle(type),
            type: type,
            fileRef: file.path,
          );

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          behavior: SnackBarBehavior.floating,
          backgroundColor: AppColors.primaryDeep,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(AppRadius.md),
          ),
          margin: const EdgeInsets.all(AppSpacing.lg),
          content: Text(
            'Report uploaded — AI analysis starting',
            style: AppTypography.labelMd.copyWith(color: Colors.white),
          ),
        ),
      );
    } catch (e) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: AppColors.danger,
          content: Text('Could not pick file: $e'),
        ),
      );
    }
  }

  String _suggestedTitle(ReportType type) {
    final today = DateFormat.yMMMd().format(DateTime.now());
    return switch (type) {
      ReportType.lab => 'Lab report · $today',
      ReportType.imaging => 'Imaging · $today',
      ReportType.discharge => 'Discharge summary · $today',
      ReportType.prescription => 'Prescription · $today',
    };
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final reports = ref.watch(reportsControllerProvider);

    return GradientScaffold(
      appBar: AppBar(
        title: const Text('Reports'),
        actions: [
          IconButton(onPressed: () {}, icon: const Icon(Icons.search_rounded)),
          const SizedBox(width: AppSpacing.sm),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showUploadSheet(context, ref),
        icon: const Icon(Icons.upload_rounded),
        label: const Text('Upload report'),
      ),
      body: reports.isEmpty
          ? EmptyState(
              icon: Icons.description_outlined,
              title: 'No reports yet',
              message:
                  'Upload a lab, imaging or discharge report and the AI will summarise it.',
              actionLabel: 'Upload report',
              onAction: () => _showUploadSheet(context, ref),
            )
          : ListView.separated(
              padding: const EdgeInsets.fromLTRB(
                AppSpacing.gutter,
                AppSpacing.md,
                AppSpacing.gutter,
                120,
              ),
              itemCount: reports.length,
              separatorBuilder: (_, __) =>
                  const SizedBox(height: AppSpacing.md),
              itemBuilder: (_, i) => _ReportRow(
                report: reports[i],
                onTap: () =>
                    context.go(Routes.reportById(reports[i].id)),
              ),
            ),
    );
  }
}

// ─── Upload bottom sheet ────────────────────────────────────────────────

class _UploadSheet extends StatefulWidget {
  const _UploadSheet({required this.onPicked});
  final void Function(ImageSource source, ReportType type) onPicked;

  @override
  State<_UploadSheet> createState() => _UploadSheetState();
}

class _UploadSheetState extends State<_UploadSheet> {
  ReportType _selectedType = ReportType.lab;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(
          AppSpacing.gutter,
          AppSpacing.md,
          AppSpacing.gutter,
          AppSpacing.lg,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 36,
                height: 4,
                decoration: BoxDecoration(
                  color: AppColors.outline,
                  borderRadius: BorderRadius.circular(99),
                ),
              ),
            ),
            const SizedBox(height: AppSpacing.lg),
            Text(
              'Upload a report',
              style: AppTypography.titleMd
                  .copyWith(color: AppColors.textPrimary, fontSize: 18),
            ),
            const SizedBox(height: AppSpacing.xs),
            Text(
              'The AI will extract key values and summarise it for you.',
              style: AppTypography.bodyMd
                  .copyWith(color: AppColors.textSecondary),
            ),
            const SizedBox(height: AppSpacing.xl),
            Text(
              'Report type',
              style: AppTypography.labelMd
                  .copyWith(color: AppColors.textPrimary),
            ),
            const SizedBox(height: AppSpacing.sm),
            Wrap(
              spacing: AppSpacing.sm,
              runSpacing: AppSpacing.sm,
              children: [
                for (final t in ReportType.values)
                  _TypeChip(
                    type: t,
                    selected: _selectedType == t,
                    onTap: () => setState(() => _selectedType = t),
                  ),
              ],
            ),
            const SizedBox(height: AppSpacing.xl),
            _SourceTile(
              icon: Icons.photo_camera_rounded,
              title: 'Take a photo',
              subtitle: 'Snap the report with your camera',
              onTap: () =>
                  widget.onPicked(ImageSource.camera, _selectedType),
            ),
            const SizedBox(height: AppSpacing.sm),
            _SourceTile(
              icon: Icons.photo_library_rounded,
              title: 'Choose from gallery',
              subtitle: 'Pick an existing image or scan',
              onTap: () =>
                  widget.onPicked(ImageSource.gallery, _selectedType),
            ),
            const SizedBox(height: AppSpacing.sm),
            _SourceTile(
              icon: Icons.picture_as_pdf_rounded,
              title: 'PDF document',
              subtitle: 'Available in the next update',
              enabled: false,
              onTap: () {},
            ),
          ],
        ),
      ),
    );
  }
}

class _TypeChip extends StatelessWidget {
  const _TypeChip({
    required this.type,
    required this.selected,
    required this.onTap,
  });
  final ReportType type;
  final bool selected;
  final VoidCallback onTap;

  String get _label => switch (type) {
        ReportType.lab => 'Lab',
        ReportType.imaging => 'Imaging',
        ReportType.discharge => 'Discharge',
        ReportType.prescription => 'Prescription',
      };

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(AppRadius.pill),
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 160),
        padding: const EdgeInsets.symmetric(
          horizontal: AppSpacing.md,
          vertical: 10,
        ),
        decoration: BoxDecoration(
          color: selected ? AppColors.primary : Colors.white,
          borderRadius: BorderRadius.circular(AppRadius.pill),
          border: Border.all(
            color: selected ? AppColors.primary : AppColors.outline,
          ),
        ),
        child: Text(
          _label,
          style: AppTypography.labelMd.copyWith(
            color: selected ? Colors.white : AppColors.textPrimary,
          ),
        ),
      ),
    );
  }
}

class _SourceTile extends StatelessWidget {
  const _SourceTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
    this.enabled = true,
  });
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  final bool enabled;

  @override
  Widget build(BuildContext context) {
    return Opacity(
      opacity: enabled ? 1 : 0.5,
      child: InkWell(
        borderRadius: BorderRadius.circular(AppRadius.lg),
        onTap: enabled ? onTap : null,
        child: Container(
          padding: const EdgeInsets.all(AppSpacing.lg),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(AppRadius.lg),
            border: Border.all(color: AppColors.outline),
          ),
          child: Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: AppColors.tintBlue,
                  borderRadius: BorderRadius.circular(AppRadius.md),
                ),
                child: Icon(icon, color: AppColors.primary),
              ),
              const SizedBox(width: AppSpacing.md),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: AppTypography.bodyLg.copyWith(
                        color: AppColors.textPrimary,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      subtitle,
                      style: AppTypography.bodyMd
                          .copyWith(color: AppColors.textSecondary),
                    ),
                  ],
                ),
              ),
              if (enabled)
                const Icon(Icons.chevron_right_rounded,
                    color: AppColors.textTertiary),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── Report row ─────────────────────────────────────────────────────────

class _ReportRow extends StatelessWidget {
  const _ReportRow({required this.report, required this.onTap});
  final MedicalReport report;
  final VoidCallback onTap;

  (IconData, Color) get _icon {
    switch (report.type) {
      case ReportType.lab:
        return (Icons.science_rounded, AppColors.primary);
      case ReportType.imaging:
        return (Icons.image_rounded, AppColors.accentCyan);
      case ReportType.discharge:
        return (Icons.local_hospital_rounded, AppColors.accentViolet);
      case ReportType.prescription:
        return (Icons.medical_services_rounded, AppColors.success);
    }
  }

  @override
  Widget build(BuildContext context) {
    final (icon, color) = _icon;
    return AppCard(
      onTap: onTap,
      accentRail: report.hasRiskFinding ? AppColors.warning : null,
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(AppRadius.sm),
            ),
            child: Icon(icon, color: color),
          ),
          const SizedBox(width: AppSpacing.md),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  report.title,
                  style: AppTypography.bodyLg.copyWith(
                    color: AppColors.textPrimary,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Text(
                      DateFormat.yMMMd().format(report.uploadedAt),
                      style: AppTypography.caption
                          .copyWith(color: AppColors.textSecondary),
                    ),
                    const SizedBox(width: AppSpacing.sm),
                    Container(
                      width: 4,
                      height: 4,
                      decoration: const BoxDecoration(
                        color: AppColors.textTertiary,
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: AppSpacing.sm),
                    StatusPill(
                      label: report.status == ReportStatus.analyzed
                          ? 'Analysed'
                          : 'Processing',
                      tone: report.status == ReportStatus.analyzed
                          ? PillTone.success
                          : PillTone.processing,
                    ),
                  ],
                ),
              ],
            ),
          ),
          const Icon(Icons.chevron_right_rounded,
              color: AppColors.textTertiary),
        ],
      ),
    );
  }
}
