enum ReportType { lab, imaging, discharge, prescription }
enum ReportStatus { processing, analyzed, failed }

/// A lab/imaging/discharge report and its AI-derived intelligence layer.
class MedicalReport {
  const MedicalReport({
    required this.id,
    required this.type,
    required this.title,
    required this.uploadedAt,
    required this.status,
    this.fileRef,
    this.summary,
    this.metrics = const [],
    this.findings = const [],
    this.hasRiskFinding = false,
  });

  final String id;
  final ReportType type;
  final String title;
  final DateTime uploadedAt;
  final ReportStatus status;

  /// Local path of the uploaded image/document.
  final String? fileRef;

  final String? summary;
  final List<ReportMetric> metrics;
  final List<ReportFinding> findings;
  final bool hasRiskFinding;

  String get typeLabel => switch (type) {
        ReportType.lab => 'Lab report',
        ReportType.imaging => 'Imaging',
        ReportType.discharge => 'Discharge summary',
        ReportType.prescription => 'Prescription',
      };
}

class ReportMetric {
  const ReportMetric({
    required this.label,
    required this.value,
    required this.unit,
    required this.refLow,
    required this.refHigh,
  });

  final String label;
  final double value;
  final String unit;
  final double refLow;
  final double refHigh;

  bool get isOutOfRange => value < refLow || value > refHigh;
}

class ReportFinding {
  const ReportFinding({
    required this.severity,
    required this.text,
    this.explanation,
  });
  final String severity; // 'info' | 'caution' | 'severe'
  final String text;
  final String? explanation;
}
