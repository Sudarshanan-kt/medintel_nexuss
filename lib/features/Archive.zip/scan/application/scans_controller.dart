import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../shared/widgets/risk_badge.dart';
import '../domain/medicine.dart';
import '../domain/prescription_scan.dart';

/// In-memory store of prescription scans the patient has captured.
///
/// Starts empty — nothing is shown until the user takes a real scan.
class ScansController extends Notifier<List<PrescriptionScan>> {
  @override
  List<PrescriptionScan> build() => const [];

  /// Called by the scanner after a photo is captured.
  PrescriptionScan addCapture(String imagePath) {
    final scan = PrescriptionScan(
      id: 's_${DateTime.now().microsecondsSinceEpoch}',
      imageRef: imagePath,
      status: ScanStatus.analyzed,
      medicines: const [],
      capturedAt: DateTime.now(),
    );
    state = [scan, ...state];
    return scan;
  }

  PrescriptionScan? getById(String id) {
    for (final s in state) {
      if (s.id == id) return s;
    }
    return null;
  }

  void addMedicine(String scanId, Medicine medicine) {
    state = [
      for (final s in state)
        if (s.id == scanId)
          s.copyWith(medicines: [...s.medicines, medicine])
        else
          s,
    ];
  }

  void updateMedicine(String scanId, Medicine medicine) {
    state = [
      for (final s in state)
        if (s.id == scanId)
          s.copyWith(
            medicines: [
              for (final m in s.medicines)
                if (m.id == medicine.id) medicine else m,
            ],
          )
        else
          s,
    ];
  }

  void removeMedicine(String scanId, String medicineId) {
    state = [
      for (final s in state)
        if (s.id == scanId)
          s.copyWith(
            medicines:
                s.medicines.where((m) => m.id != medicineId).toList(),
          )
        else
          s,
    ];
  }

  void deleteScan(String id) {
    state = state.where((s) => s.id != id).toList();
  }

  /// Convenience: total number of distinct medicines across all scans.
  int get totalMedicineCount =>
      state.fold(0, (sum, s) => sum + s.medicines.length);

  int get riskAlertCount {
    var c = 0;
    for (final s in state) {
      for (final m in s.medicines) {
        if (m.riskLevel != RiskLevel.none) c++;
      }
    }
    return c;
  }
}

final scansControllerProvider =
    NotifierProvider<ScansController, List<PrescriptionScan>>(
  ScansController.new,
);
