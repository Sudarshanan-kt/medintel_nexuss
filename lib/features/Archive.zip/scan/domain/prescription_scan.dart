import 'medicine.dart';

enum ScanStatus { queued, processing, analyzed, failed }

/// A prescription scan and the medicines the patient has attached to it.
class PrescriptionScan {
  const PrescriptionScan({
    required this.id,
    required this.imageRef,
    required this.status,
    required this.medicines,
    this.capturedAt,
    this.note,
  });

  final String id;
  final String imageRef;
  final ScanStatus status;
  final List<Medicine> medicines;
  final DateTime? capturedAt;
  final String? note;

  bool get hasRisk => medicines.any((m) => m.riskLevel.index > 0);

  PrescriptionScan copyWith({
    String? imageRef,
    ScanStatus? status,
    List<Medicine>? medicines,
    DateTime? capturedAt,
    String? note,
  }) =>
      PrescriptionScan(
        id: id,
        imageRef: imageRef ?? this.imageRef,
        status: status ?? this.status,
        medicines: medicines ?? this.medicines,
        capturedAt: capturedAt ?? this.capturedAt,
        note: note ?? this.note,
      );
}
