import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../../../shared/widgets/insight_card.dart';
import '../../../shared/widgets/risk_badge.dart';
import '../../reports/application/reports_controller.dart';
import '../../reports/domain/medical_report.dart';
import '../../scan/application/scans_controller.dart';
import '../../scan/domain/prescription_scan.dart';

/// A single insight on the dashboard feed.
class DashboardInsight {
  const DashboardInsight({
    required this.id,
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.tone,
  });

  final String id;
  final IconData icon;
  final String title;
  final String subtitle;
  final InsightTone tone;
}

/// Read-only snapshot of the dashboard, fully derived from the real scan
/// and report stores. No fabricated demo data here.
class DashboardState {
  const DashboardState({
    required this.scansCount,
    required this.reportsCount,
    required this.medicineCount,
    required this.riskAlertCount,
    required this.recentScans,
    required this.recentReports,
    required this.insights,
  });

  final int scansCount;
  final int reportsCount;
  final int medicineCount;
  final int riskAlertCount;
  final List<PrescriptionScan> recentScans;
  final List<MedicalReport> recentReports;
  final List<DashboardInsight> insights;

  bool get isEmpty =>
      scansCount == 0 && reportsCount == 0 && medicineCount == 0;
}

final dashboardStateProvider = Provider<DashboardState>((ref) {
  final scans = ref.watch(scansControllerProvider);
  final reports = ref.watch(reportsControllerProvider);

  final medicineCount = scans.fold<int>(0, (a, s) => a + s.medicines.length);
  var riskAlerts = 0;
  for (final s in scans) {
    for (final m in s.medicines) {
      if (m.riskLevel != RiskLevel.none) riskAlerts++;
    }
  }
  if (reports.any((r) => r.hasRiskFinding)) riskAlerts++;

  final insights = <DashboardInsight>[];

  // Risk-flagged medicines from the most recent scan.
  for (final scan in scans) {
    for (final m in scan.medicines.where(
      (m) => m.riskLevel != RiskLevel.none,
    )) {
      insights.add(DashboardInsight(
        id: '${scan.id}_${m.id}',
        icon: Icons.warning_amber_rounded,
        title: '${m.name} ${m.strength} flagged',
        subtitle: m.riskNote ?? 'Tap to view details',
        tone: m.riskLevel == RiskLevel.severe
            ? InsightTone.alert
            : InsightTone.caution,
      ));
    }
  }

  // Reports with findings.
  for (final r in reports.where((r) => r.hasRiskFinding)) {
    insights.add(DashboardInsight(
      id: 'rpt_${r.id}',
      icon: Icons.description_rounded,
      title: r.title,
      subtitle: r.summary ?? 'Review the analysis',
      tone: InsightTone.caution,
    ));
  }

  // Recent scan summary if no risk insights yet.
  if (insights.isEmpty && scans.isNotEmpty) {
    final s = scans.first;
    insights.add(DashboardInsight(
      id: 'scan_${s.id}',
      icon: Icons.medication_rounded,
      title: 'Recent scan · ${s.medicines.length} medicine'
          '${s.medicines.length == 1 ? '' : 's'}',
      subtitle: s.capturedAt != null
          ? 'Captured ${DateFormat.MMMd().add_jm().format(s.capturedAt!)}'
          : 'Tap to view',
      tone: InsightTone.neutral,
    ));
  }

  return DashboardState(
    scansCount: scans.length,
    reportsCount: reports.length,
    medicineCount: medicineCount,
    riskAlertCount: riskAlerts,
    recentScans: scans.take(3).toList(),
    recentReports: reports.take(3).toList(),
    insights: insights.take(4).toList(),
  );
});
