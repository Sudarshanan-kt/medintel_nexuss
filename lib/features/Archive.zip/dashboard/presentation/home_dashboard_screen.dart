import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

import '../../../app/router/route_names.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_shadows.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/utils/extensions.dart';
import '../../../shared/widgets/widgets.dart';
import '../../auth/application/auth_controller.dart';
import '../../reports/domain/medical_report.dart';
import '../../scan/domain/prescription_scan.dart';
import '../application/dashboard_controller.dart';
import '../domain/quick_action.dart';

class HomeDashboardScreen extends ConsumerWidget {
  const HomeDashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final auth = ref.watch(authControllerProvider).valueOrNull;
    final dash = ref.watch(dashboardStateProvider);
    final name = auth?.user?.displayName ?? 'Aravind Kumar';
    final greeting = DateTime.now().greeting;
    final cols = context.quickActionColumns;

    return GradientScaffold(
      body: SafeArea(
        bottom: false,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(
            AppSpacing.gutter,
            AppSpacing.lg,
            AppSpacing.gutter,
            AppSpacing.xxxl,
          ),
          physics: const BouncingScrollPhysics(),
          children: [
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '$greeting,',
                        style: AppTypography.bodyMd
                            .copyWith(color: AppColors.textSecondary),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: AppTypography.headlineMd
                            .copyWith(color: AppColors.textPrimary),
                      ),
                    ],
                  ),
                ),
                _Avatar(name: name),
              ],
            ),

            const SizedBox(height: AppSpacing.xl),

            // Hero card — empty CTA if no data, summary card otherwise.
            if (dash.isEmpty)
              _GettingStartedCard(onScan: () => context.go(Routes.scan))
            else
              _SummaryCard(state: dash),

            const SizedBox(height: AppSpacing.xl),

            _SearchBar(),

            const SizedBox(height: AppSpacing.xl),

            SectionHeader(
              title: 'Quick actions',
              actionLabel: 'See all',
              onAction: () {},
            ),
            const SizedBox(height: AppSpacing.md),
            GridView.count(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisCount: cols,
              mainAxisSpacing: AppSpacing.md,
              crossAxisSpacing: AppSpacing.md,
              childAspectRatio: 0.95,
              children: [
                for (final a in QuickAction.values)
                  _QuickTile(
                    icon: a.icon,
                    label: a.label,
                    tint: a.tint,
                    onTap: () {
                      if (a.routePath != null) {
                        context.go(a.routePath!);
                      } else {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            behavior: SnackBarBehavior.floating,
                            backgroundColor: AppColors.primaryDeep,
                            shape: RoundedRectangleBorder(
                              borderRadius:
                                  BorderRadius.circular(AppRadius.md),
                            ),
                            margin: const EdgeInsets.all(AppSpacing.lg),
                            content: Text(
                              '${a.label.replaceAll('\n', ' ')} — coming soon',
                              style: AppTypography.labelMd
                                  .copyWith(color: Colors.white),
                            ),
                          ),
                        );
                      }
                    },
                  ),
              ],
            ),

            const SizedBox(height: AppSpacing.xl),

            SectionHeader(title: 'Health insights'),
            const SizedBox(height: AppSpacing.md),
            if (dash.insights.isEmpty)
              _EmptyHint(
                icon: Icons.health_and_safety_outlined,
                title: 'No insights yet',
                message:
                    'Insights show up once you\'ve scanned a prescription or uploaded a report.',
              )
            else
              for (final ins in dash.insights) ...[
                InsightCard(
                  icon: ins.icon,
                  title: ins.title,
                  subtitle: ins.subtitle,
                  tone: ins.tone,
                  onTap: () {},
                ),
                const SizedBox(height: AppSpacing.md),
              ],

            const SizedBox(height: AppSpacing.lg),

            SectionHeader(title: 'Recent activity'),
            const SizedBox(height: AppSpacing.md),
            if (dash.recentScans.isEmpty && dash.recentReports.isEmpty)
              _EmptyHint(
                icon: Icons.timeline_rounded,
                title: 'No activity yet',
                message:
                    'Scans and report uploads will be listed here in order.',
              )
            else
              ..._buildActivity(context, dash.recentScans, dash.recentReports),
          ],
        ),
      ),
    );
  }

  List<Widget> _buildActivity(
    BuildContext context,
    List<PrescriptionScan> scans,
    List<MedicalReport> reports,
  ) {
    final items = <_ActivityItem>[];
    for (final s in scans) {
      items.add(_ActivityItem(
        timestamp: s.capturedAt ?? DateTime.now(),
        icon: Icons.center_focus_strong_rounded,
        color: AppColors.primary,
        title: 'Prescription scan',
        subtitle:
            '${s.medicines.length} medicine${s.medicines.length == 1 ? '' : 's'} recorded',
        onTap: () => context.go(Routes.scanResultId(s.id)),
      ));
    }
    for (final r in reports) {
      items.add(_ActivityItem(
        timestamp: r.uploadedAt,
        icon: Icons.description_rounded,
        color: AppColors.accentCyan,
        title: r.title,
        subtitle: r.status == ReportStatus.analyzed
            ? 'Analysed'
            : 'Processing',
        onTap: () => context.go(Routes.reportById(r.id)),
      ));
    }
    items.sort((a, b) => b.timestamp.compareTo(a.timestamp));
    return [
      for (final it in items) ...[
        _ActivityRow(item: it),
        const SizedBox(height: AppSpacing.md),
      ],
    ];
  }
}

// ─────────────────────────────────────────────────────────────────────────
// Empty / first-run hero CTA
// ─────────────────────────────────────────────────────────────────────────

class _GettingStartedCard extends StatelessWidget {
  const _GettingStartedCard({required this.onScan});
  final VoidCallback onScan;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(AppSpacing.xl),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFF1E3A8A),
            AppColors.primary,
            AppColors.accentViolet,
          ],
        ),
        borderRadius: BorderRadius.circular(AppRadius.xl),
        boxShadow: AppShadows.brandGlow,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(
                horizontal: AppSpacing.sm, vertical: 4),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.16),
              borderRadius: BorderRadius.circular(AppRadius.pill),
            ),
            child: Text(
              'GET STARTED',
              style: AppTypography.caption.copyWith(
                color: Colors.white,
                fontWeight: FontWeight.w700,
                letterSpacing: 1.6,
              ),
            ),
          ),
          const SizedBox(height: AppSpacing.md),
          Text(
            'Welcome to MedIntel Nexus.',
            style: AppTypography.titleMd
                .copyWith(color: Colors.white, fontSize: 22, height: 1.3),
          ),
          const SizedBox(height: 4),
          Text(
            'Capture your first prescription to start building your medication record.',
            style: AppTypography.bodyMd
                .copyWith(color: Colors.white.withValues(alpha: 0.85)),
          ),
          const SizedBox(height: AppSpacing.lg),
          InkWell(
            borderRadius: BorderRadius.circular(AppRadius.md),
            onTap: onScan,
            child: Container(
              padding: const EdgeInsets.symmetric(
                horizontal: AppSpacing.lg,
                vertical: AppSpacing.md,
              ),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(AppRadius.md),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.center_focus_strong_rounded,
                      color: AppColors.primaryDeep, size: 20),
                  const SizedBox(width: AppSpacing.sm),
                  Text(
                    'Scan a prescription',
                    style: AppTypography.labelMd.copyWith(
                      color: AppColors.primaryDeep,
                      fontSize: 14,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────
// Real summary card (replaces the demo hero once data exists)
// ─────────────────────────────────────────────────────────────────────────

class _SummaryCard extends StatelessWidget {
  const _SummaryCard({required this.state});
  final DashboardState state;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(AppSpacing.xl),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFF1E3A8A),
            AppColors.primary,
            AppColors.accentViolet,
          ],
        ),
        borderRadius: BorderRadius.circular(AppRadius.xl),
        boxShadow: AppShadows.brandGlow,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: AppSpacing.sm, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.16),
                  borderRadius: BorderRadius.circular(AppRadius.pill),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 6,
                      height: 6,
                      decoration: BoxDecoration(
                        color: state.riskAlertCount > 0
                            ? const Color(0xFFFCA5A5)
                            : const Color(0xFF4ADE80),
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      state.riskAlertCount > 0
                          ? 'ATTENTION'
                          : 'ALL CLEAR',
                      style: AppTypography.caption.copyWith(
                        color: Colors.white,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 1.4,
                      ),
                    ),
                  ],
                ),
              ),
              const Spacer(),
              Text(
                DateFormat.MMMd().format(DateTime.now()).toUpperCase(),
                style: AppTypography.caption.copyWith(
                  color: Colors.white.withValues(alpha: 0.7),
                  letterSpacing: 1.6,
                ),
              ),
            ],
          ),
          const SizedBox(height: AppSpacing.lg),
          Text(
            'Your record',
            style: AppTypography.titleMd
                .copyWith(color: Colors.white, fontSize: 18),
          ),
          const SizedBox(height: 2),
          Text(
            '${state.medicineCount} medicine'
            '${state.medicineCount == 1 ? '' : 's'} across '
            '${state.scansCount} scan${state.scansCount == 1 ? '' : 's'}',
            style: AppTypography.bodyMd.copyWith(
              color: Colors.white.withValues(alpha: 0.85),
            ),
          ),
          const SizedBox(height: AppSpacing.lg),
          Row(
            children: [
              Expanded(
                child: _PillStat(
                  icon: Icons.center_focus_strong_rounded,
                  label: 'Scans',
                  value: '${state.scansCount}',
                ),
              ),
              const SizedBox(width: AppSpacing.sm),
              Expanded(
                child: _PillStat(
                  icon: Icons.description_rounded,
                  label: 'Reports',
                  value: '${state.reportsCount}',
                ),
              ),
              const SizedBox(width: AppSpacing.sm),
              Expanded(
                child: _PillStat(
                  icon: Icons.warning_amber_rounded,
                  label: 'Alerts',
                  value: '${state.riskAlertCount}',
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _PillStat extends StatelessWidget {
  const _PillStat({
    required this.icon,
    required this.label,
    required this.value,
  });
  final IconData icon;
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSpacing.sm,
        vertical: AppSpacing.sm,
      ),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.14),
        borderRadius: BorderRadius.circular(AppRadius.md),
        border: Border.all(color: Colors.white.withValues(alpha: 0.22)),
      ),
      child: Row(
        children: [
          Icon(icon, color: Colors.white, size: 16),
          const SizedBox(width: 6),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  value,
                  style: AppTypography.labelMd
                      .copyWith(color: Colors.white, fontSize: 14),
                ),
                Text(
                  label,
                  style: AppTypography.caption.copyWith(
                    color: Colors.white.withValues(alpha: 0.7),
                    fontSize: 9,
                    letterSpacing: 0.8,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────
// Search bar
// ─────────────────────────────────────────────────────────────────────────

class _SearchBar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSpacing.lg,
        vertical: AppSpacing.sm,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(AppRadius.pill),
        border: Border.all(color: AppColors.outline),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0F1E293B),
            blurRadius: 16,
            offset: Offset(0, 6),
          ),
        ],
      ),
      child: Row(
        children: [
          const Icon(Icons.search_rounded, color: AppColors.textSecondary),
          const SizedBox(width: AppSpacing.md),
          Expanded(
            child: Text(
              'Search medicines, reports…',
              style: AppTypography.bodyMd
                  .copyWith(color: AppColors.textTertiary),
            ),
          ),
          Container(
            width: 38,
            height: 38,
            decoration: const BoxDecoration(
              gradient: AppColors.brandGradient,
              shape: BoxShape.circle,
            ),
            child: const Icon(Icons.mic_rounded,
                color: Colors.white, size: 18),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────
// Quick tile
// ─────────────────────────────────────────────────────────────────────────

class _QuickTile extends StatelessWidget {
  const _QuickTile({
    required this.icon,
    required this.label,
    required this.tint,
    required this.onTap,
  });
  final IconData icon;
  final String label;
  final Color tint;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(AppRadius.md),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(
          vertical: AppSpacing.md,
          horizontal: AppSpacing.sm,
        ),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(AppRadius.md),
          border: Border.all(color: AppColors.outline),
          boxShadow: const [
            BoxShadow(
              color: Color(0x0F1E293B),
              blurRadius: 14,
              offset: Offset(0, 6),
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: tint,
                borderRadius: BorderRadius.circular(AppRadius.md),
              ),
              child: Icon(icon, color: AppColors.primaryDeep, size: 22),
            ),
            const SizedBox(height: AppSpacing.sm),
            Flexible(
              child: Text(
                label,
                maxLines: 2,
                textAlign: TextAlign.center,
                overflow: TextOverflow.ellipsis,
                style: AppTypography.caption.copyWith(
                  color: AppColors.textPrimary,
                  fontWeight: FontWeight.w600,
                  height: 1.2,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Avatar extends StatelessWidget {
  const _Avatar({required this.name});
  final String name;

  String get _initials {
    final parts = name.trim().split(' ');
    if (parts.isEmpty || parts[0].isEmpty) return '?';
    if (parts.length == 1) return parts[0].substring(0, 1).toUpperCase();
    return (parts[0][0] + parts[1][0]).toUpperCase();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 48,
      height: 48,
      decoration: BoxDecoration(
        gradient: AppColors.brandGradient,
        borderRadius: BorderRadius.circular(AppRadius.md),
      ),
      alignment: Alignment.center,
      child: Text(
        _initials,
        style: AppTypography.labelMd
            .copyWith(color: Colors.white, fontSize: 14),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────
// Activity row
// ─────────────────────────────────────────────────────────────────────────

class _ActivityItem {
  _ActivityItem({
    required this.timestamp,
    required this.icon,
    required this.color,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });
  final DateTime timestamp;
  final IconData icon;
  final Color color;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
}

class _ActivityRow extends StatelessWidget {
  const _ActivityRow({required this.item});
  final _ActivityItem item;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(AppRadius.lg),
      onTap: item.onTap,
      child: Container(
        padding: const EdgeInsets.all(AppSpacing.md),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(AppRadius.lg),
          border: Border.all(color: AppColors.outline),
          boxShadow: AppShadows.card,
        ),
        child: Row(
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: item.color.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(AppRadius.sm),
              ),
              child: Icon(item.icon, color: item.color, size: 20),
            ),
            const SizedBox(width: AppSpacing.md),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    item.title,
                    style: AppTypography.bodyLg.copyWith(
                      color: AppColors.textPrimary,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  Text(
                    '${item.subtitle} · ${DateFormat.MMMd().add_jm().format(item.timestamp)}',
                    style: AppTypography.caption
                        .copyWith(color: AppColors.textSecondary),
                  ),
                ],
              ),
            ),
            const Icon(Icons.chevron_right_rounded,
                color: AppColors.textTertiary),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────
// Empty hint
// ─────────────────────────────────────────────────────────────────────────

class _EmptyHint extends StatelessWidget {
  const _EmptyHint({
    required this.icon,
    required this.title,
    required this.message,
  });
  final IconData icon;
  final String title;
  final String message;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(AppSpacing.lg),
      decoration: BoxDecoration(
        color: AppColors.tintBlue.withValues(alpha: 0.45),
        borderRadius: BorderRadius.circular(AppRadius.lg),
        border: Border.all(color: AppColors.outline),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: AppColors.tintBlue,
              borderRadius: BorderRadius.circular(AppRadius.sm),
            ),
            child: Icon(icon, color: AppColors.primary, size: 20),
          ),
          const SizedBox(width: AppSpacing.md),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: AppTypography.bodyLg.copyWith(
                    color: AppColors.textPrimary,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  message,
                  style: AppTypography.bodyMd
                      .copyWith(color: AppColors.textSecondary),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
