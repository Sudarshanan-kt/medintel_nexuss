import '../../../core/utils/result.dart';
import 'auth_user.dart';

/// Result of an OTP request — carries the short-lived verification id the
/// backend issued so the verify step can be correlated.
class OtpChallenge {
  const OtpChallenge({required this.verificationId, required this.phone});
  final String verificationId;
  final String phone;
}

/// Contract the data layer must satisfy. The domain layer owns this
/// interface; `data/auth_repository_impl.dart` implements it against Dio +
/// secure storage.
abstract interface class AuthRepository {
  /// Returns the currently persisted session, if any (offline-first boot).
  Future<Result<AuthUser?>> currentUser();

  Future<Result<OtpChallenge>> requestOtp(String phone);

  /// Verifies the code and persists tokens. Returns the authenticated user.
  Future<Result<AuthUser>> verifyOtp({
    required String verificationId,
    required String code,
  });

  Future<Result<AuthUser>> loginWithEmail({
    required String email,
    required String password,
  });

  /// Persists the patient health profile and flips `onboardingComplete`.
  Future<Result<AuthUser>> completeOnboarding(Map<String, dynamic> profile);

  Future<Result<void>> signOut();
}
