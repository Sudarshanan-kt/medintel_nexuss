import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../app/router/route_names.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../shared/widgets/widgets.dart';

class _ValueProp {
  const _ValueProp(this.icon, this.title, this.body);
  final IconData icon;
  final String title;
  final String body;
}

const _props = <_ValueProp>[
  _ValueProp(
    Icons.center_focus_strong_rounded,
    'Scan any prescription',
    'Point your camera. We extract the medicines, dosages and flag risks.',
  ),
  _ValueProp(
    Icons.psychology_alt_rounded,
    'AI clinical intelligence',
    'Drug interactions, allergy risk and adherence — explained in plain language.',
  ),
  _ValueProp(
    Icons.translate_rounded,
    'Multilingual assistant',
    'Ask in English, Tamil or Hindi. Voice-enabled, always with you.',
  ),
];

class WelcomeScreen extends ConsumerStatefulWidget {
  const WelcomeScreen({super.key});

  @override
  ConsumerState<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends ConsumerState<WelcomeScreen> {
  final _controller = PageController();
  int _page = 0;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GradientScaffold(
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: AppSpacing.gutter),
        child: Column(
          children: [
            const SizedBox(height: AppSpacing.lg),
            Expanded(
              child: PageView.builder(
                controller: _controller,
                itemCount: _props.length,
                onPageChanged: (i) => setState(() => _page = i),
                itemBuilder: (_, i) => _Prop(prop: _props[i]),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(
                _props.length,
                (i) => AnimatedContainer(
                  duration: const Duration(milliseconds: 240),
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  width: i == _page ? 24 : 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: i == _page
                        ? AppColors.primary
                        : AppColors.outline,
                    borderRadius: BorderRadius.circular(99),
                  ),
                ),
              ),
            ),
            const SizedBox(height: AppSpacing.xxl),
            PrimaryButton(
              label: 'Continue with phone',
              icon: Icons.smartphone_rounded,
              onPressed: () => context.go(Routes.phone),
            ),
            const SizedBox(height: AppSpacing.md),
            SecondaryButton(
              label: 'Use email instead',
              onPressed: () => context.go(Routes.emailLogin),
            ),
            const SizedBox(height: AppSpacing.lg),
            Text(
              'By continuing you agree to our Terms and Privacy Policy.',
              textAlign: TextAlign.center,
              style: AppTypography.caption
                  .copyWith(color: AppColors.textTertiary),
            ),
            const SizedBox(height: AppSpacing.lg),
          ],
        ),
      ),
    );
  }
}

class _Prop extends StatelessWidget {
  const _Prop({required this.prop});
  final _ValueProp prop;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
          width: 112,
          height: 112,
          decoration: BoxDecoration(
            gradient: AppColors.brandGradient,
            borderRadius: BorderRadius.circular(28),
          ),
          child: Icon(prop.icon, color: Colors.white, size: 56),
        ),
        const SizedBox(height: AppSpacing.xxl),
        Text(
          prop.title,
          textAlign: TextAlign.center,
          style: AppTypography.headlineMd.copyWith(color: scheme.onSurface),
        ),
        const SizedBox(height: AppSpacing.md),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg),
          child: Text(
            prop.body,
            textAlign: TextAlign.center,
            style: AppTypography.bodyLg.copyWith(
              color: AppColors.textSecondary,
            ),
          ),
        ),
      ],
    );
  }
}
