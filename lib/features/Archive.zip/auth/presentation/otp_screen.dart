import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../app/router/route_names.dart';
import '../../../core/constants/app_constants.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../shared/widgets/widgets.dart';
import '../application/auth_controller.dart';

class OtpScreen extends ConsumerStatefulWidget {
  const OtpScreen({super.key});

  @override
  ConsumerState<OtpScreen> createState() => _OtpScreenState();
}

class _OtpScreenState extends ConsumerState<OtpScreen> {
  Timer? _ticker;
  int _seconds = AppConstants.otpResendCooldown.inSeconds;
  bool _hasError = false;

  @override
  void initState() {
    super.initState();
    _startCooldown();
  }

  void _startCooldown() {
    _ticker?.cancel();
    setState(() => _seconds = AppConstants.otpResendCooldown.inSeconds);
    _ticker = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return;
      if (_seconds <= 0) {
        t.cancel();
      } else {
        setState(() => _seconds--);
      }
    });
  }

  @override
  void dispose() {
    _ticker?.cancel();
    super.dispose();
  }

  Future<void> _verify(String code) async {
    setState(() => _hasError = false);
    await ref.read(authControllerProvider.notifier).verifyOtp(code);
    if (!mounted) return;
    final state = ref.read(authControllerProvider).valueOrNull;
    if (state?.errorMessage != null) {
      setState(() => _hasError = true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final auth = ref.watch(authControllerProvider);
    final phone = auth.valueOrNull?.challenge?.phone ?? 'your number';

    return GradientScaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded),
          onPressed: () => context.go(Routes.phone),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: AppSpacing.gutter),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Enter the code',
              style: AppTypography.headlineMd
                  .copyWith(color: AppColors.textPrimary),
            ),
            const SizedBox(height: AppSpacing.sm),
            RichText(
              text: TextSpan(
                style: AppTypography.bodyMd
                    .copyWith(color: AppColors.textSecondary),
                children: [
                  const TextSpan(text: 'We sent a 6-digit code to '),
                  TextSpan(
                    text: phone,
                    style: const TextStyle(
                      fontWeight: FontWeight.w700,
                      color: AppColors.textPrimary,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: AppSpacing.xxxl),
            OtpInputRow(
              hasError: _hasError,
              onCompleted: _verify,
            ),
            const SizedBox(height: AppSpacing.lg),
            if (_hasError)
              Text(
                'That code didn\'t work. Try again.',
                style: AppTypography.caption.copyWith(color: AppColors.danger),
              ),
            const SizedBox(height: AppSpacing.xxxl),
            Center(
              child: _seconds > 0
                  ? Text(
                      'Resend code in 0:${_seconds.toString().padLeft(2, '0')}',
                      style: AppTypography.bodyMd
                          .copyWith(color: AppColors.textTertiary),
                    )
                  : TextButton(
                      onPressed: _startCooldown,
                      child: Text(
                        'Resend code',
                        style: AppTypography.labelMd
                            .copyWith(color: AppColors.primary),
                      ),
                    ),
            ),
            const Spacer(),
            if (auth.isLoading)
              const Center(
                child: Padding(
                  padding: EdgeInsets.only(bottom: AppSpacing.lg),
                  child: CircularProgressIndicator(strokeWidth: 2.4),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
