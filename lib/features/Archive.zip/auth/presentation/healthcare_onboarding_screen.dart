import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../shared/widgets/widgets.dart';
import '../application/auth_controller.dart';

/// Multi-step healthcare onboarding: identity → health profile → allergies +
/// conditions → consent. Writes the patient record and flips
/// `onboardingComplete` so the router lets the user into the shell.
class HealthcareOnboardingScreen extends ConsumerStatefulWidget {
  const HealthcareOnboardingScreen({super.key});

  @override
  ConsumerState<HealthcareOnboardingScreen> createState() =>
      _HealthcareOnboardingScreenState();
}

class _HealthcareOnboardingScreenState
    extends ConsumerState<HealthcareOnboardingScreen> {
  int _step = 0;
  static const _steps = ['Identity', 'Health profile', 'Risk factors', 'Consent'];

  final _name = TextEditingController();
  final _dob = TextEditingController();
  final _heightCm = TextEditingController();
  final _weightKg = TextEditingController();
  final _allergies = <String>{};
  final _conditions = <String>{};
  bool _consented = false;

  static const _allergyOptions = [
    'Penicillin', 'Sulfa', 'Aspirin', 'Latex', 'Peanuts', 'Eggs',
  ];
  static const _conditionOptions = [
    'Diabetes', 'Hypertension', 'Asthma', 'Heart disease', 'Kidney disease',
  ];

  @override
  void dispose() {
    _name.dispose();
    _dob.dispose();
    _heightCm.dispose();
    _weightKg.dispose();
    super.dispose();
  }

  Future<void> _next() async {
    if (_step < _steps.length - 1) {
      setState(() => _step++);
      return;
    }
    await ref.read(authControllerProvider.notifier).completeOnboarding({
      'fullName': _name.text.trim(),
      'dob': _dob.text.trim(),
      'heightCm': _heightCm.text.trim(),
      'weightKg': _weightKg.text.trim(),
      'allergies': _allergies.toList(),
      'conditions': _conditions.toList(),
      'consentSigned': _consented,
    });
  }

  bool get _canContinue {
    switch (_step) {
      case 0:
        return _name.text.trim().length >= 2;
      case 3:
        return _consented;
      default:
        return true;
    }
  }

  @override
  Widget build(BuildContext context) {
    final auth = ref.watch(authControllerProvider);
    return GradientScaffold(
      appBar: AppBar(
        leading: _step == 0
            ? null
            : IconButton(
                icon: const Icon(Icons.arrow_back_rounded),
                onPressed: () => setState(() => _step--),
              ),
        title: Text('Step ${_step + 1} of ${_steps.length}'),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: AppSpacing.gutter),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Step bar.
            Row(
              children: List.generate(_steps.length, (i) {
                final filled = i <= _step;
                return Expanded(
                  child: Container(
                    margin:
                        EdgeInsets.only(right: i == _steps.length - 1 ? 0 : 6),
                    height: 6,
                    decoration: BoxDecoration(
                      color: filled ? AppColors.primary : AppColors.outline,
                      borderRadius: BorderRadius.circular(99),
                    ),
                  ),
                );
              }),
            ),
            const SizedBox(height: AppSpacing.xl),
            Text(
              _steps[_step],
              style: AppTypography.headlineMd
                  .copyWith(color: AppColors.textPrimary),
            ),
            const SizedBox(height: AppSpacing.sm),
            Text(
              _stepDescription,
              style: AppTypography.bodyMd
                  .copyWith(color: AppColors.textSecondary),
            ),
            const SizedBox(height: AppSpacing.xl),
            Expanded(
              child: SingleChildScrollView(child: _stepBody()),
            ),
            PrimaryButton(
              label: _step == _steps.length - 1 ? 'Finish setup' : 'Continue',
              isLoading: auth.isLoading,
              onPressed: _canContinue ? _next : null,
            ),
            const SizedBox(height: AppSpacing.lg),
          ],
        ),
      ),
    );
  }

  String get _stepDescription {
    switch (_step) {
      case 0:
        return 'Help us personalise your experience.';
      case 1:
        return 'Used to compute dosage ranges and adherence.';
      case 2:
        return 'These power your interaction and allergy alerts.';
      case 3:
        return 'Read and confirm to continue.';
      default:
        return '';
    }
  }

  Widget _stepBody() {
    switch (_step) {
      case 0:
        return Column(
          children: [
            AppTextField(
              controller: _name,
              label: 'Full name',
              hint: 'e.g. Aravind Kumar',
              onChanged: (_) => setState(() {}),
            ),
            const SizedBox(height: AppSpacing.lg),
            AppTextField(
              controller: _dob,
              label: 'Date of birth',
              hint: 'DD / MM / YYYY',
              prefixIcon: Icons.cake_outlined,
            ),
          ],
        );
      case 1:
        return Row(
          children: [
            Expanded(
              child: AppTextField(
                controller: _heightCm,
                label: 'Height (cm)',
                hint: '172',
                keyboardType: TextInputType.number,
              ),
            ),
            const SizedBox(width: AppSpacing.lg),
            Expanded(
              child: AppTextField(
                controller: _weightKg,
                label: 'Weight (kg)',
                hint: '68',
                keyboardType: TextInputType.number,
              ),
            ),
          ],
        );
      case 2:
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Allergies',
              style: AppTypography.labelMd
                  .copyWith(color: AppColors.textPrimary),
            ),
            const SizedBox(height: AppSpacing.sm),
            _ChipGroup(
              options: _allergyOptions,
              selected: _allergies,
              onChanged: (s) => setState(() {
                _allergies
                  ..clear()
                  ..addAll(s);
              }),
            ),
            const SizedBox(height: AppSpacing.xl),
            Text(
              'Conditions',
              style: AppTypography.labelMd
                  .copyWith(color: AppColors.textPrimary),
            ),
            const SizedBox(height: AppSpacing.sm),
            _ChipGroup(
              options: _conditionOptions,
              selected: _conditions,
              onChanged: (s) => setState(() {
                _conditions
                  ..clear()
                  ..addAll(s);
              }),
            ),
          ],
        );
      case 3:
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            AppCard(
              padding: const EdgeInsets.all(AppSpacing.lg),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 44,
                        height: 44,
                        decoration: BoxDecoration(
                          color: AppColors.tintBlue,
                          borderRadius: BorderRadius.circular(AppRadius.sm),
                        ),
                        child: const Icon(Icons.shield_rounded,
                            color: AppColors.primary),
                      ),
                      const SizedBox(width: AppSpacing.md),
                      Expanded(
                        child: Text(
                          'Consent to data processing',
                          style: AppTypography.titleMd.copyWith(
                              color: AppColors.textPrimary, fontSize: 16),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: AppSpacing.md),
                  Text(
                    'You allow MedIntel Nexus to process your prescriptions, '
                    'reports and health profile to produce AI insights. Data '
                    'is encrypted at rest and never sold. You can revoke at '
                    'any time.',
                    style: AppTypography.bodyLg
                        .copyWith(color: AppColors.textPrimary, height: 1.55),
                  ),
                ],
              ),
            ),
            const SizedBox(height: AppSpacing.lg),
            InkWell(
              borderRadius: BorderRadius.circular(AppRadius.lg),
              onTap: () => setState(() => _consented = !_consented),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 180),
                padding: const EdgeInsets.all(AppSpacing.lg),
                decoration: BoxDecoration(
                  color: _consented ? AppColors.tintBlue : Colors.white,
                  borderRadius: BorderRadius.circular(AppRadius.lg),
                  border: Border.all(
                    color: _consented
                        ? AppColors.primary
                        : AppColors.outline,
                    width: _consented ? 2 : 1,
                  ),
                ),
                child: Row(
                  children: [
                    AnimatedContainer(
                      duration: const Duration(milliseconds: 180),
                      width: 28,
                      height: 28,
                      decoration: BoxDecoration(
                        color: _consented
                            ? AppColors.primary
                            : Colors.transparent,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(
                          color: _consented
                              ? AppColors.primary
                              : AppColors.textTertiary,
                          width: 2,
                        ),
                      ),
                      child: _consented
                          ? const Icon(Icons.check_rounded,
                              color: Colors.white, size: 20)
                          : null,
                    ),
                    const SizedBox(width: AppSpacing.md),
                    Expanded(
                      child: Text(
                        'I have read and agree',
                        style: AppTypography.bodyLg.copyWith(
                          color: AppColors.textPrimary,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
      default:
        return const SizedBox.shrink();
    }
  }
}

class _ChipGroup extends StatelessWidget {
  const _ChipGroup({
    required this.options,
    required this.selected,
    required this.onChanged,
  });

  final List<String> options;
  final Set<String> selected;
  final ValueChanged<Set<String>> onChanged;

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: AppSpacing.sm,
      runSpacing: AppSpacing.sm,
      children: options.map((o) {
        final isSel = selected.contains(o);
        return GestureDetector(
          onTap: () {
            final next = Set<String>.from(selected);
            isSel ? next.remove(o) : next.add(o);
            onChanged(next);
          },
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 160),
            padding: const EdgeInsets.symmetric(
              horizontal: AppSpacing.md,
              vertical: 10,
            ),
            decoration: BoxDecoration(
              color: isSel ? AppColors.primary : Theme.of(context).cardColor,
              borderRadius: BorderRadius.circular(AppRadius.pill),
              border: Border.all(
                color: isSel ? AppColors.primary : AppColors.outline,
              ),
            ),
            child: Text(
              o,
              style: AppTypography.labelMd.copyWith(
                color: isSel ? Colors.white : AppColors.textPrimary,
              ),
            ),
          ),
        );
      }).toList(),
    );
  }
}
