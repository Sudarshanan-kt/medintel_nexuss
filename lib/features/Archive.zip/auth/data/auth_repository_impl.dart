import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import '../../../core/constants/app_constants.dart';
import '../../../core/errors/failure.dart';
import '../../../core/network/dio_client.dart';
import '../../../core/utils/result.dart';
import '../domain/auth_repository.dart';
import '../domain/auth_user.dart';

/// Demo implementation of [AuthRepository].
///
/// It simulates the real network round-trips (latency, token persistence,
/// the new-user fork) so the scaffold runs end-to-end with no backend. Swap
/// the bodies for real Dio calls against `ApiEndpoints` for production —
/// the interface, the controller and every screen stay untouched.
class AuthRepositoryImpl implements AuthRepository {
  AuthRepositoryImpl(this._storage);

  final FlutterSecureStorage _storage;

  static const _latency = Duration(milliseconds: 900);

  @override
  Future<Result<AuthUser?>> currentUser() async {
    try {
      final token = await _storage.read(key: AppConstants.kAccessToken);
      if (token == null) return const Success(null);
      final onboarded =
          await _storage.read(key: AppConstants.kOnboardingComplete);
      return Success(
        AuthUser(
          id: 'usr_demo',
          role: UserRole.patient,
          onboardingComplete: onboarded == 'true',
          fullName: onboarded == 'true' ? 'Aravind Kumar' : null,
          phone: '+91 90000 00000',
        ),
      );
    } catch (_) {
      return const ResultFailure(CacheFailure());
    }
  }

  @override
  Future<Result<OtpChallenge>> requestOtp(String phone) async {
    await Future<void>.delayed(_latency);
    return Success(
      OtpChallenge(verificationId: 'vrf_${phone.hashCode}', phone: phone),
    );
  }

  @override
  Future<Result<AuthUser>> verifyOtp({
    required String verificationId,
    required String code,
  }) async {
    await Future<void>.delayed(_latency);
    if (code != '123456' && code.length == AppConstants.otpLength) {
      // Demo: any 6-digit code is accepted; 123456 is the "happy path".
    }
    await _persistTokens();
    await _storage.write(
      key: AppConstants.kOnboardingComplete,
      value: 'true',
    );
    return const Success(
      AuthUser(
        id: 'usr_demo',
        role: UserRole.patient,
        onboardingComplete: true,
        fullName: 'Aravind Kumar',
        phone: '+91 90000 00000',
      ),
    );
  }

  @override
  Future<Result<AuthUser>> loginWithEmail({
    required String email,
    required String password,
  }) async {
    await Future<void>.delayed(_latency);
    await _persistTokens();
    await _storage.write(
      key: AppConstants.kOnboardingComplete,
      value: 'true',
    );
    return Success(
      AuthUser(
        id: 'usr_demo',
        role: UserRole.patient,
        onboardingComplete: true,
        fullName: 'Aravind Kumar',
        email: email,
      ),
    );
  }

  @override
  Future<Result<AuthUser>> completeOnboarding(
    Map<String, dynamic> profile,
  ) async {
    await Future<void>.delayed(_latency);
    await _storage.write(
      key: AppConstants.kOnboardingComplete,
      value: 'true',
    );
    return Success(
      AuthUser(
        id: 'usr_demo',
        role: UserRole.patient,
        onboardingComplete: true,
        fullName: profile['fullName'] as String? ?? 'Aravind Kumar',
        phone: '+91 90000 00000',
      ),
    );
  }

  @override
  Future<Result<void>> signOut() async {
    await _storage.deleteAll();
    return const Success(null);
  }

  Future<void> _persistTokens() async {
    await _storage.write(
      key: AppConstants.kAccessToken,
      value: 'demo.access.token',
    );
    await _storage.write(
      key: AppConstants.kRefreshToken,
      value: 'demo.refresh.token',
    );
  }
}

/// DI: binds the [AuthRepository] interface to its implementation.
final authRepositoryProvider = Provider<AuthRepository>(
  (ref) => AuthRepositoryImpl(ref.watch(secureStorageProvider)),
);
