import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/utils/result.dart';
import '../data/auth_repository_impl.dart';
import '../domain/auth_repository.dart';
import '../domain/auth_user.dart';

/// The four lifecycle phases of a session. The router redirect (see
/// `app_router.dart`) is driven entirely by this.
enum AuthStatus { unknown, unauthenticated, onboarding, authenticated }

/// Immutable session state exposed to the whole app.
class AuthState {
  const AuthState({
    required this.status,
    this.user,
    this.challenge,
    this.errorMessage,
  });

  const AuthState.unknown() : this(status: AuthStatus.unknown);

  final AuthStatus status;
  final AuthUser? user;
  final OtpChallenge? challenge;
  final String? errorMessage;

  AuthState copyWith({
    AuthStatus? status,
    AuthUser? user,
    OtpChallenge? challenge,
    String? errorMessage,
  }) {
    return AuthState(
      status: status ?? this.status,
      user: user ?? this.user,
      challenge: challenge ?? this.challenge,
      errorMessage: errorMessage,
    );
  }
}

/// The single source of truth for authentication.
///
/// Screens call into this notifier; the router *watches* it and redirects.
/// State transitions are explicit and exhaustive.
class AuthController extends AsyncNotifier<AuthState> {
  AuthRepository get _repo => ref.read(authRepositoryProvider);

  @override
  Future<AuthState> build() async {
    final result = await _repo.currentUser();
    return result.when(
      success: (user) {
        if (user == null) {
          return const AuthState(status: AuthStatus.unauthenticated);
        }
        return AuthState(
          status: user.onboardingComplete
              ? AuthStatus.authenticated
              : AuthStatus.onboarding,
          user: user,
        );
      },
      failure: (_) => const AuthState(status: AuthStatus.unauthenticated),
    );
  }

  Future<bool> requestOtp(String phone) async {
    state = const AsyncLoading();
    final result = await _repo.requestOtp(phone);
    return result.when(
      success: (challenge) {
        state = AsyncData(
          AuthState(
            status: AuthStatus.unauthenticated,
            challenge: challenge,
          ),
        );
        return true;
      },
      failure: (f) {
        state = AsyncData(
          AuthState(
            status: AuthStatus.unauthenticated,
            errorMessage: f.message,
          ),
        );
        return false;
      },
    );
  }

  Future<void> verifyOtp(String code) async {
    final challenge = state.valueOrNull?.challenge;
    if (challenge == null) return;
    state = const AsyncLoading();
    final result = await _repo.verifyOtp(
      verificationId: challenge.verificationId,
      code: code,
    );
    state = AsyncData(_fromUserResult(result));
  }

  Future<void> loginWithEmail(String email, String password) async {
    state = const AsyncLoading();
    final result = await _repo.loginWithEmail(
      email: email,
      password: password,
    );
    state = AsyncData(_fromUserResult(result));
  }

  Future<void> completeOnboarding(Map<String, dynamic> profile) async {
    state = const AsyncLoading();
    final result = await _repo.completeOnboarding(profile);
    state = AsyncData(_fromUserResult(result));
  }

  Future<void> signOut() async {
    await _repo.signOut();
    state = const AsyncData(
      AuthState(status: AuthStatus.unauthenticated),
    );
  }

  AuthState _fromUserResult(Result<AuthUser> result) {
    return result.when(
      success: (user) => AuthState(
        status: user.onboardingComplete
            ? AuthStatus.authenticated
            : AuthStatus.onboarding,
        user: user,
      ),
      failure: (f) => AuthState(
        status: AuthStatus.unauthenticated,
        errorMessage: f.message,
      ),
    );
  }
}

final authControllerProvider =
    AsyncNotifierProvider<AuthController, AuthState>(AuthController.new);

/// Convenience: the resolved [AuthStatus], defaulting to `unknown` while the
/// controller is still booting.
final authStatusProvider = Provider<AuthStatus>((ref) {
  return ref
          .watch(authControllerProvider)
          .valueOrNull
          ?.status ??
      AuthStatus.unknown;
});
