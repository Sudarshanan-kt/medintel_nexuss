import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../data/assistant_service.dart';
import '../data/voice_service.dart';
import '../domain/chat_message.dart';
import '../domain/voice_state.dart';

class AssistantState {
  const AssistantState({
    required this.messages,
    required this.language,
    this.phase = VoicePhase.idle,
    this.liveTranscript = '',
    this.amplitude = 0,
    this.errorMessage,
  });

  final List<ChatMessage> messages;
  final AssistantLanguage language;
  final VoicePhase phase;

  /// Live partial transcript shown while the user is speaking.
  final String liveTranscript;

  /// Mic amplitude 0..1 while listening. Drives the waveform animation.
  final double amplitude;

  final String? errorMessage;

  AssistantState copyWith({
    List<ChatMessage>? messages,
    AssistantLanguage? language,
    VoicePhase? phase,
    String? liveTranscript,
    double? amplitude,
    String? errorMessage,
  }) {
    return AssistantState(
      messages: messages ?? this.messages,
      language: language ?? this.language,
      phase: phase ?? this.phase,
      liveTranscript: liveTranscript ?? this.liveTranscript,
      amplitude: amplitude ?? this.amplitude,
      errorMessage: errorMessage,
    );
  }

  ChatMessage? get lastAssistantMessage {
    for (final m in messages.reversed) {
      if (!m.isUser) return m;
    }
    return null;
  }

  ChatMessage? get lastUserMessage {
    for (final m in messages.reversed) {
      if (m.isUser) return m;
    }
    return null;
  }
}

class AssistantController extends Notifier<AssistantState> {
  late final VoiceService _voice = ref.read(voiceServiceProvider);
  late final AssistantService _service = ref.read(assistantServiceProvider);

  @override
  AssistantState build() {
    // Best-effort: warm up the voice subsystems on first access.
    Future.microtask(_voice.initialise);
    return AssistantState(
      language: AssistantLanguage.english,
      messages: [
        ChatMessage(
          id: 'welcome',
          role: MessageRole.assistant,
          content:
              "Hi Aravind. I'm your MedIntel assistant. Tap and hold to talk — ask me about your medicines, reports, or how to take a dose. I'm here in English or Tamil.",
          language: AssistantLanguage.english,
        ),
      ],
    );
  }

  void setLanguage(AssistantLanguage lang) {
    state = state.copyWith(language: lang, errorMessage: null);
  }

  /// Begin a voice turn — open the microphone, stream partials, on final
  /// submit the transcript to the LLM, then speak the answer aloud.
  Future<void> startListening() async {
    if (state.phase == VoicePhase.listening) return;
    await _voice.stopSpeaking();

    state = state.copyWith(
      phase: VoicePhase.listening,
      liveTranscript: '',
      errorMessage: null,
    );

    await _voice.listen(
      language: state.language,
      onPartial: (t) {
        if (state.phase != VoicePhase.listening) return;
        state = state.copyWith(liveTranscript: t);
      },
      onAmplitude: (a) {
        if (state.phase != VoicePhase.listening) return;
        state = state.copyWith(amplitude: a);
      },
      onFinal: (t) async {
        final clean = t.trim();
        if (clean.isEmpty) {
          state = state.copyWith(
            phase: VoicePhase.idle,
            liveTranscript: '',
            amplitude: 0,
          );
          return;
        }
        await _processTurn(clean);
      },
    );
  }

  /// Stop a listening turn early (button released). Submits the partial
  /// transcript if there is one.
  Future<void> stopListening() async {
    final partial = state.liveTranscript.trim();
    await _voice.stopListening();
    if (state.phase != VoicePhase.listening) return;
    if (partial.isEmpty) {
      state = state.copyWith(phase: VoicePhase.idle, liveTranscript: '');
      return;
    }
    await _processTurn(partial);
  }

  Future<void> _processTurn(String userText) async {
    final lang = state.language;
    final userMsg = ChatMessage(
      id: 'u_${DateTime.now().microsecondsSinceEpoch}',
      role: MessageRole.user,
      content: userText,
      language: lang,
    );

    state = state.copyWith(
      messages: [...state.messages, userMsg],
      phase: VoicePhase.thinking,
      liveTranscript: '',
    );

    try {
      final reply = await _service.reply(
        prompt: userText,
        history: state.messages,
        language: lang,
      );

      final assistantMsg = ChatMessage(
        id: 'a_${DateTime.now().microsecondsSinceEpoch}',
        role: MessageRole.assistant,
        content: reply,
        language: lang,
      );

      state = state.copyWith(
        messages: [...state.messages, assistantMsg],
        phase: VoicePhase.speaking,
      );

      await _voice.speak(reply, lang);
      if (state.phase == VoicePhase.speaking) {
        state = state.copyWith(phase: VoicePhase.idle);
      }
    } catch (e) {
      state = state.copyWith(
        phase: VoicePhase.error,
        errorMessage: 'Could not reach the assistant. Try again.',
      );
    }
  }

  /// Send a typed message (fallback when the user prefers keyboard).
  Future<void> sendText(String text) async {
    if (text.trim().isEmpty) return;
    await _voice.stopSpeaking();
    await _processTurn(text.trim());
  }

  Future<void> interrupt() async {
    await _voice.stopSpeaking();
    await _voice.stopListening();
    state = state.copyWith(phase: VoicePhase.idle, liveTranscript: '');
  }
}

final assistantControllerProvider =
    NotifierProvider<AssistantController, AssistantState>(
  AssistantController.new,
);
