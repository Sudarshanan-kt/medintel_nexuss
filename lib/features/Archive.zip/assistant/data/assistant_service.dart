import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import '../../../core/network/dio_client.dart';
import '../domain/chat_message.dart';

/// Talks to the underlying LLM.
///
/// Resolution order for the API key:
///   1. Runtime override saved to secure storage via the in-app settings.
///   2. `--dart-define=GROQ_API_KEY=...` build flag.
///   3. None — fall back to the curated demo response set.
///
/// Provider: Groq (Llama 3.3 70B). Free tier, sub-second responses, native
/// Tamil & Hindi quality. Get a key at console.groq.com/keys.
class AssistantService {
  AssistantService({required this.dio, required this.storage});

  final Dio dio;
  final FlutterSecureStorage storage;

  static const String _kGroqApiKey = 'mn_groq_api_key';
  static const String _envKey =
      String.fromEnvironment('GROQ_API_KEY', defaultValue: '');
  static const String _endpoint =
      'https://api.groq.com/openai/v1/chat/completions';
  static const String _model = 'llama-3.3-70b-versatile';

  Future<String?> getApiKey() async {
    final stored = await storage.read(key: _kGroqApiKey);
    if (stored != null && stored.isNotEmpty) return stored;
    if (_envKey.isNotEmpty) return _envKey;
    return null;
  }

  Future<void> setApiKey(String? key) async {
    if (key == null || key.trim().isEmpty) {
      await storage.delete(key: _kGroqApiKey);
    } else {
      await storage.write(key: _kGroqApiKey, value: key.trim());
    }
  }

  Future<bool> hasApiKey() async => (await getApiKey()) != null;

  /// Generate an assistant reply for [prompt]. Honours conversation history
  /// and the active language.
  Future<String> reply({
    required String prompt,
    required List<ChatMessage> history,
    required AssistantLanguage language,
  }) async {
    final apiKey = await getApiKey();
    if (apiKey == null) return _fallback(prompt, language);

    try {
      final messages = <Map<String, String>>[
        {'role': 'system', 'content': _systemPrompt(language)},
        for (final m in history.take(10))
          {
            'role': m.isUser ? 'user' : 'assistant',
            'content': m.content,
          },
        {'role': 'user', 'content': prompt},
      ];

      final res = await dio.post<String>(
        _endpoint,
        options: Options(
          headers: {
            'Authorization': 'Bearer $apiKey',
            'Content-Type': 'application/json',
          },
          responseType: ResponseType.plain,
          receiveTimeout: const Duration(seconds: 25),
          sendTimeout: const Duration(seconds: 15),
        ),
        data: jsonEncode({
          'model': _model,
          'messages': messages,
          'temperature': 0.7,
          'max_tokens': 350,
        }),
      );

      final json = jsonDecode(res.data ?? '{}') as Map<String, dynamic>;
      final choices = (json['choices'] as List?) ?? const [];
      if (choices.isEmpty) return _fallback(prompt, language);
      final msg = (choices.first as Map)['message'] as Map?;
      final content = msg?['content'] as String?;
      return content?.trim().isNotEmpty == true
          ? content!.trim()
          : _fallback(prompt, language);
    } on DioException catch (e) {
      debugPrint('Groq request failed: ${e.message}');
      return _fallback(prompt, language);
    } catch (e) {
      debugPrint('Groq parse failed: $e');
      return _fallback(prompt, language);
    }
  }

  String _systemPrompt(AssistantLanguage lang) {
    final base = '''
You are MedIntel Nexus's clinical assistant — calm, warm, conversational and
human. You talk to the patient like a thoughtful friend who happens to know
medicine. Avoid robotic language. Vary your sentence structure. You may use
contractions. Address the patient by first name (Aravind) occasionally.

You help with: medicines, prescriptions, lab reports, risk flags, dosage
schedules, adherence, side effects, drug interactions, and general health
questions. Keep replies short by default (2-4 sentences) but go deeper if
the user asks. Never invent specific lab values, dosages, or prescriptions
you weren't told about; if you don't have the data, say so honestly.

You are not a doctor. For diagnosis, dosing changes, severe symptoms, or
emergencies, point the user to their clinician. If the user describes chest
pain, suicidal thoughts, severe bleeding, stroke symptoms, anaphylaxis or
similar emergencies, urge them to call emergency services immediately.
''';
    return switch (lang) {
      AssistantLanguage.english => '$base\nRespond in natural, conversational English.',
      AssistantLanguage.tamil =>
        '$base\nRespond in spoken Tamil (தமிழ்) — the warm, everyday register people actually use, not literary Tamil. Mix in occasional English words only where natural (medicine names, units).',
      AssistantLanguage.hindi =>
        '$base\nRespond in spoken Hindi (हिन्दी) — the warm, everyday register, not formal Hindi.',
    };
  }

  String _fallback(String prompt, AssistantLanguage lang) {
    final p = prompt.toLowerCase().trim();

    String pick(List<String> en, List<String> ta, List<String> hi) {
      final list = switch (lang) {
        AssistantLanguage.english => en,
        AssistantLanguage.tamil => ta,
        AssistantLanguage.hindi => hi,
      };
      return list[DateTime.now().millisecondsSinceEpoch % list.length];
    }

    if (RegExp(r'\b(hi|hello|hey|namaste|vanakkam|வணக்கம்|नमस्ते)\b')
        .hasMatch(p)) {
      return pick(
        [
          "Hi Aravind. What's on your mind today?",
          "Hey — anything you'd like me to look up about your prescriptions?",
        ],
        [
          "வணக்கம் அரவிந்த். இன்று என்ன கேக்கணும்?",
          "ஹாய், என்ன உதவி வேண்டும்?",
        ],
        ["नमस्ते अरविंद, क्या मदद चाहिए?"],
      );
    }

    if (p.contains('ibuprofen') ||
        p.contains('warfarin') ||
        p.contains('interaction')) {
      return pick(
        [
          "Ibuprofen with Warfarin can bump up bleeding risk — that's why I'd lean towards paracetamol for pain. But please run any switch by your doctor first.",
        ],
        [
          "வார்ஃபரின் உடன் ஐபுப்ரோஃபன் சேர்த்தா ரத்தப்போக்கு ரிஸ்க் கூடிடும். வலி இருக்கா? பாராசிட்டமால் சேஃபா இருக்கும். ஆனா மாற்றுவதுக்கு முன்னாடி டாக்டரிடம் கேக்கணும்.",
        ],
        [
          "वारफरिन के साथ इबुप्रोफेन से ब्लीडिंग बढ़ सकती है। दर्द हो तो पैरासिटामॉल बेहतर — पर बदलाव से पहले डॉक्टर से पूछो।",
        ],
      );
    }

    if (p.contains('adherence') ||
        p.contains('missed') ||
        p.contains('dose')) {
      return pick(
        [
          "Your adherence this week is 86 percent — solid. If you miss one, take it as soon as you remember, unless the next dose is close. Never double up.",
        ],
        [
          "இந்த வாரம் உங்க டோஸ் கடைப்பிடிப்பு 86%, நல்லா இருக்கு. ஒரு டோஸ் தவறிட்டா, அடுத்த நேரம் வெகுதூரம் இல்லைன்னா உடனே எடுத்துக்கங்க. டபுள் வேண்டாம்.",
        ],
        [
          "इस हफ्ते आपका 86% — बढ़िया है। खुराक छूट गई तो जल्दी ले लो, पर अगली खुराक नज़दीक हो तो डबल मत करना।",
        ],
      );
    }

    return pick(
      [
        "I hear you. To answer properly I'd want to look at your latest scan or report — want me to pull that up?",
        "Tell me a bit more — is this about a medicine you've been prescribed, a lab value, or something you're feeling right now?",
      ],
      [
        "புரியுது. சரியான பதில் சொல்ல சமீபத்திய ஸ்கேன் அல்லது அறிக்கையை பார்க்கணும். எடுக்கட்டுமா?",
        "கொஞ்சம் மேலே சொல்லுங்க — மருந்து பத்தியா, ஆய்வக மதிப்பு பத்தியா, அல்லது இப்போ உடம்பு எப்படி இருக்கு?",
      ],
      ["समझ गया, थोड़ी और बात बताओ — दवा, रिपोर्ट या तबियत?"],
    );
  }
}

final assistantServiceProvider = Provider<AssistantService>((ref) {
  return AssistantService(
    dio: Dio(),
    storage: ref.watch(secureStorageProvider),
  );
});
