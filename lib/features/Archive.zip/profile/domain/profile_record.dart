/// Domain models for the patient's profile.
///
/// All plain Dart — no Flutter imports.

enum AppLanguage {
  english('en', 'English'),
  tamil('ta', 'தமிழ்'),
  hindi('hi', 'हिन्दी');

  const AppLanguage(this.code, this.label);
  final String code;
  final String label;

  static AppLanguage fromCode(String code) {
    return AppLanguage.values.firstWhere(
      (l) => l.code == code,
      orElse: () => AppLanguage.english,
    );
  }
}

enum NotificationLevel {
  all('All'),
  important('Important only'),
  none('Off');

  const NotificationLevel(this.label);
  final String label;
}

class EmergencyContact {
  const EmergencyContact({
    required this.id,
    required this.name,
    required this.relation,
    required this.phone,
  });
  final String id;
  final String name;
  final String relation;
  final String phone;

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'relation': relation,
        'phone': phone,
      };

  static EmergencyContact fromJson(Map<String, dynamic> j) =>
      EmergencyContact(
        id: j['id'] as String,
        name: j['name'] as String,
        relation: j['relation'] as String,
        phone: j['phone'] as String,
      );
}

class ProfileRecord {
  const ProfileRecord({
    required this.allergies,
    required this.conditions,
    required this.emergencyContacts,
    required this.biometricEnabled,
    required this.notifications,
    required this.language,
  });

  final List<String> allergies;
  final List<String> conditions;
  final List<EmergencyContact> emergencyContacts;
  final bool biometricEnabled;
  final NotificationLevel notifications;
  final AppLanguage language;

  static const initial = ProfileRecord(
    allergies: ['Penicillin', 'Aspirin'],
    conditions: ['Hypertension'],
    emergencyContacts: [
      EmergencyContact(
        id: 'c1',
        name: 'Lakshmi Kumar',
        relation: 'Spouse',
        phone: '+91 90000 11111',
      ),
      EmergencyContact(
        id: 'c2',
        name: 'Dr. Reddy',
        relation: 'Primary care',
        phone: '+91 90000 22222',
      ),
    ],
    biometricEnabled: true,
    notifications: NotificationLevel.all,
    language: AppLanguage.english,
  );

  ProfileRecord copyWith({
    List<String>? allergies,
    List<String>? conditions,
    List<EmergencyContact>? emergencyContacts,
    bool? biometricEnabled,
    NotificationLevel? notifications,
    AppLanguage? language,
  }) {
    return ProfileRecord(
      allergies: allergies ?? this.allergies,
      conditions: conditions ?? this.conditions,
      emergencyContacts: emergencyContacts ?? this.emergencyContacts,
      biometricEnabled: biometricEnabled ?? this.biometricEnabled,
      notifications: notifications ?? this.notifications,
      language: language ?? this.language,
    );
  }
}
