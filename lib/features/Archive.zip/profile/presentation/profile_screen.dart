import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_shadows.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../shared/widgets/widgets.dart';
import '../../auth/application/auth_controller.dart';
import '../../dashboard/application/dashboard_controller.dart';
import '../../scan/application/scans_controller.dart';
import '../application/profile_controller.dart';
import '../domain/profile_record.dart';
import 'profile_sheets.dart';

class ProfileScreen extends ConsumerWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(authControllerProvider).valueOrNull?.user;
    final profile = ref.watch(profileControllerProvider);
    final dash = ref.watch(dashboardStateProvider);
    final name = user?.displayName ?? 'Aravind Kumar';
    final phone = user?.phone ?? '+91 90000 00000';

    return GradientScaffold(
      body: SafeArea(
        bottom: false,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(
            AppSpacing.gutter,
            AppSpacing.lg,
            AppSpacing.gutter,
            AppSpacing.xxxl,
          ),
          physics: const BouncingScrollPhysics(),
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    'Profile',
                    style: AppTypography.headlineMd
                        .copyWith(color: AppColors.textPrimary),
                  ),
                ),
                _IconChip(
                  icon: Icons.qr_code_rounded,
                  onTap: () => showInfoSheet(
                    context,
                    icon: Icons.qr_code_rounded,
                    title: 'Patient QR',
                    body:
                        'In an emergency, a clinician can scan this QR to access your allergies, conditions and emergency contacts. Coming in the next update.',
                  ),
                ),
                const SizedBox(width: AppSpacing.sm),
                _IconChip(
                  icon: Icons.notifications_none_rounded,
                  onTap: () => openNotificationsSheet(context, ref),
                ),
              ],
            ),

            const SizedBox(height: AppSpacing.xl),

            _HeroCard(name: name, phone: phone),

            const SizedBox(height: AppSpacing.lg),

            Row(
              children: [
                Expanded(
                  child: _StatTile(
                    label: 'Scans',
                    value: '${dash.scansCount}',
                    icon: Icons.center_focus_strong_rounded,
                    tint: AppColors.tintBlue,
                    fg: AppColors.primary,
                  ),
                ),
                const SizedBox(width: AppSpacing.md),
                Expanded(
                  child: _StatTile(
                    label: 'Reports',
                    value: '${dash.reportsCount}',
                    icon: Icons.description_rounded,
                    tint: AppColors.tintCyan,
                    fg: AppColors.accentCyan,
                  ),
                ),
                const SizedBox(width: AppSpacing.md),
                Expanded(
                  child: _StatTile(
                    label: 'Medicines',
                    value: '${dash.medicineCount}',
                    icon: Icons.medication_rounded,
                    tint: AppColors.tintGreen,
                    fg: AppColors.success,
                  ),
                ),
              ],
            ),

            const SizedBox(height: AppSpacing.xl),

            _SectionLabel(label: 'Health record'),
            const SizedBox(height: AppSpacing.sm),
            _SettingsCard(
              children: [
                _TileRow(
                  icon: Icons.bloodtype_rounded,
                  tint: AppColors.tintRed,
                  fg: AppColors.danger,
                  label: 'Allergies',
                  trailing: _summary(profile.allergies, 'None'),
                  onTap: () => openAllergiesSheet(context, ref),
                ),
                const _Divider(),
                _TileRow(
                  icon: Icons.monitor_heart_rounded,
                  tint: AppColors.tintBlue,
                  fg: AppColors.primary,
                  label: 'Conditions',
                  trailing: _summary(profile.conditions, 'None'),
                  onTap: () => openConditionsSheet(context, ref),
                ),
                const _Divider(),
                _TileRow(
                  icon: Icons.medication_rounded,
                  tint: AppColors.tintGreen,
                  fg: AppColors.success,
                  label: 'Active medicines',
                  trailing: '${dash.medicineCount}',
                  onTap: () => showInfoSheet(
                    context,
                    icon: Icons.medication_rounded,
                    title: 'Active medicines',
                    body: _medicinesSummary(ref),
                  ),
                ),
                const _Divider(),
                _TileRow(
                  icon: Icons.contact_emergency_rounded,
                  tint: AppColors.tintAmber,
                  fg: AppColors.warning,
                  label: 'Emergency contacts',
                  trailing: '${profile.emergencyContacts.length}',
                  onTap: () => openEmergencyContactsSheet(context, ref),
                ),
              ],
            ),

            const SizedBox(height: AppSpacing.xl),

            _SectionLabel(label: 'Preferences'),
            const SizedBox(height: AppSpacing.sm),
            _SettingsCard(
              children: [
                _ToggleTile(
                  icon: Icons.fingerprint_rounded,
                  tint: AppColors.tintBlue,
                  fg: AppColors.primary,
                  label: 'Biometric unlock',
                  value: profile.biometricEnabled,
                  onChanged: (v) => ref
                      .read(profileControllerProvider.notifier)
                      .setBiometric(v),
                ),
                const _Divider(),
                _TileRow(
                  icon: Icons.language_rounded,
                  tint: AppColors.tintViolet,
                  fg: AppColors.accentViolet,
                  label: 'Language',
                  trailing: profile.language.label,
                  onTap: () => openLanguageSheet(context, ref),
                ),
                const _Divider(),
                _TileRow(
                  icon: Icons.notifications_active_rounded,
                  tint: AppColors.tintCyan,
                  fg: AppColors.accentCyan,
                  label: 'Notifications',
                  trailing: profile.notifications.label,
                  onTap: () => openNotificationsSheet(context, ref),
                ),
                const _Divider(),
                _TileRow(
                  icon: Icons.privacy_tip_rounded,
                  tint: AppColors.tintAmber,
                  fg: AppColors.warning,
                  label: 'Privacy & data',
                  onTap: () => showInfoSheet(
                    context,
                    icon: Icons.privacy_tip_rounded,
                    title: 'Privacy & data',
                    body:
                        'Your prescriptions and reports are encrypted at rest and in transit. AI analysis runs server-side and is never sold or used to train external models. You can request export or deletion at any time.',
                  ),
                ),
              ],
            ),

            const SizedBox(height: AppSpacing.xl),

            _SectionLabel(label: 'About'),
            const SizedBox(height: AppSpacing.sm),
            _SettingsCard(
              children: [
                _TileRow(
                  icon: Icons.help_outline_rounded,
                  tint: AppColors.tintBlue,
                  fg: AppColors.primary,
                  label: 'Help & support',
                  onTap: () => showInfoSheet(
                    context,
                    icon: Icons.help_outline_rounded,
                    title: 'Help & support',
                    body:
                        'Need help? Email support@medintelnexus.app or visit medintelnexus.app/help — typical response time is 24 hours.',
                  ),
                ),
                const _Divider(),
                _TileRow(
                  icon: Icons.description_outlined,
                  tint: AppColors.tintBlue,
                  fg: AppColors.primary,
                  label: 'Terms & privacy',
                  onTap: () => showInfoSheet(
                    context,
                    icon: Icons.description_outlined,
                    title: 'Terms & privacy',
                    body:
                        'MedIntel Nexus is an AI-assisted clinical intelligence platform, not a replacement for a doctor. Use of the app is governed by our Terms of Service and Privacy Policy at medintelnexus.app/legal.',
                  ),
                ),
                const _Divider(),
                _TileRow(
                  icon: Icons.info_outline_rounded,
                  tint: AppColors.tintBlue,
                  fg: AppColors.primary,
                  label: 'App version',
                  trailing: '1.0.0',
                  onTap: () => showInfoSheet(
                    context,
                    icon: Icons.info_outline_rounded,
                    title: 'MedIntel Nexus · v1.0.0',
                    body:
                        'Build 1 · Patient client. AI-Powered Clinical Intelligence & Prescription Risk Analysis Platform.',
                  ),
                ),
              ],
            ),

            const SizedBox(height: AppSpacing.xl),

            _SignOutButton(
              onTap: () =>
                  ref.read(authControllerProvider.notifier).signOut(),
            ),

            const SizedBox(height: AppSpacing.lg),
            Center(
              child: Text(
                'MedIntel Nexus · Patient',
                style: AppTypography.caption
                    .copyWith(color: AppColors.textTertiary),
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _summary(List<String> items, String emptyLabel) {
    if (items.isEmpty) return emptyLabel;
    if (items.length == 1) return items.first;
    if (items.length == 2) return '${items[0]} · ${items[1]}';
    return '${items[0]} · ${items[1]} · +${items.length - 2}';
  }

  String _medicinesSummary(WidgetRef ref) {
    final scans = ref.read(scansControllerProvider);
    final names = <String>[
      for (final s in scans)
        for (final m in s.medicines)
          '${m.name}${m.strength.isEmpty ? '' : ' ${m.strength}'}',
    ];
    if (names.isEmpty) {
      return 'No medicines recorded yet. Scan a prescription and add its '
          'medicines — they\'ll be listed here.';
    }
    return names.join(' · ');
  }
}

// ─────────────────────────────────────────────────────────────────────────
// Sub-widgets
// ─────────────────────────────────────────────────────────────────────────

class _HeroCard extends StatelessWidget {
  const _HeroCard({required this.name, required this.phone});
  final String name;
  final String phone;

  String get _initials {
    final parts = name.trim().split(' ');
    if (parts.isEmpty || parts[0].isEmpty) return '?';
    if (parts.length == 1) return parts[0].substring(0, 1).toUpperCase();
    return (parts[0][0] + parts[1][0]).toUpperCase();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(AppSpacing.xl),
      decoration: BoxDecoration(
        gradient: AppColors.brandGradient,
        borderRadius: BorderRadius.circular(AppRadius.xl),
        boxShadow: AppShadows.brandGlow,
      ),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 64,
                height: 64,
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.18),
                  borderRadius: BorderRadius.circular(AppRadius.md),
                  border: Border.all(
                    color: Colors.white.withValues(alpha: 0.35),
                  ),
                ),
                alignment: Alignment.center,
                child: Text(
                  _initials,
                  style: AppTypography.headlineMd
                      .copyWith(color: Colors.white, fontSize: 22),
                ),
              ),
              const SizedBox(width: AppSpacing.lg),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: AppTypography.titleMd
                          .copyWith(color: Colors.white, fontSize: 18),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      phone,
                      style: AppTypography.bodyMd.copyWith(
                        color: Colors.white.withValues(alpha: 0.78),
                      ),
                    ),
                    const SizedBox(height: AppSpacing.sm),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: AppSpacing.sm,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.20),
                        borderRadius:
                            BorderRadius.circular(AppRadius.pill),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(
                            width: 6,
                            height: 6,
                            decoration: const BoxDecoration(
                              color: Colors.white,
                              shape: BoxShape.circle,
                            ),
                          ),
                          const SizedBox(width: 6),
                          Text(
                            'Patient account',
                            style: AppTypography.caption.copyWith(
                              color: Colors.white,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: AppSpacing.lg),
          Row(
            children: [
              Expanded(
                child: _OutlineActionButton(
                  icon: Icons.edit_rounded,
                  label: 'Edit profile',
                  onTap: () {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Edit profile — coming soon'),
                        behavior: SnackBarBehavior.floating,
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(width: AppSpacing.md),
              Expanded(
                child: _OutlineActionButton(
                  icon: Icons.share_rounded,
                  label: 'Share record',
                  onTap: () {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Share record — coming soon'),
                        behavior: SnackBarBehavior.floating,
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _OutlineActionButton extends StatelessWidget {
  const _OutlineActionButton({
    required this.icon,
    required this.label,
    required this.onTap,
  });
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(AppRadius.md),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(
          horizontal: AppSpacing.md,
          vertical: AppSpacing.md,
        ),
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: 0.14),
          borderRadius: BorderRadius.circular(AppRadius.md),
          border: Border.all(
              color: Colors.white.withValues(alpha: 0.28)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: Colors.white, size: 18),
            const SizedBox(width: 8),
            Text(
              label,
              style: AppTypography.labelMd
                  .copyWith(color: Colors.white, fontSize: 13),
            ),
          ],
        ),
      ),
    );
  }
}

class _StatTile extends StatelessWidget {
  const _StatTile({
    required this.label,
    required this.value,
    required this.icon,
    required this.tint,
    required this.fg,
  });
  final String label;
  final String value;
  final IconData icon;
  final Color tint;
  final Color fg;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(AppSpacing.md),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(AppRadius.lg),
        border: Border.all(color: AppColors.outline),
        boxShadow: AppShadows.card,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: tint,
              borderRadius: BorderRadius.circular(AppRadius.sm),
            ),
            child: Icon(icon, color: fg, size: 18),
          ),
          const SizedBox(height: AppSpacing.sm),
          Text(
            value,
            style: AppTypography.headlineMd
                .copyWith(color: AppColors.textPrimary, fontSize: 22),
          ),
          Text(
            label,
            style: AppTypography.caption
                .copyWith(color: AppColors.textSecondary),
          ),
        ],
      ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  const _SectionLabel({required this.label});
  final String label;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: AppSpacing.sm),
      child: Text(
        label.toUpperCase(),
        style: AppTypography.labelMd.copyWith(
          color: AppColors.textTertiary,
          fontSize: 11,
          letterSpacing: 1.4,
        ),
      ),
    );
  }
}

class _SettingsCard extends StatelessWidget {
  const _SettingsCard({required this.children});
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(AppRadius.lg),
        border: Border.all(color: AppColors.outline),
        boxShadow: AppShadows.card,
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(AppRadius.lg),
        child: Column(children: children),
      ),
    );
  }
}

class _TileRow extends StatelessWidget {
  const _TileRow({
    required this.icon,
    required this.tint,
    required this.fg,
    required this.label,
    required this.onTap,
    this.trailing,
  });
  final IconData icon;
  final Color tint;
  final Color fg;
  final String label;
  final VoidCallback onTap;
  final String? trailing;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: AppSpacing.lg,
          vertical: AppSpacing.md,
        ),
        child: Row(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: tint,
                borderRadius: BorderRadius.circular(AppRadius.sm),
              ),
              child: Icon(icon, color: fg, size: 18),
            ),
            const SizedBox(width: AppSpacing.md),
            Expanded(
              child: Text(
                label,
                style: AppTypography.bodyLg.copyWith(
                  color: AppColors.textPrimary,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
            if (trailing != null) ...[
              Flexible(
                child: Text(
                  trailing!,
                  textAlign: TextAlign.end,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: AppTypography.bodyMd.copyWith(
                    color: AppColors.textTertiary,
                  ),
                ),
              ),
              const SizedBox(width: 6),
            ],
            const Icon(Icons.chevron_right_rounded,
                color: AppColors.textTertiary, size: 20),
          ],
        ),
      ),
    );
  }
}

class _ToggleTile extends StatelessWidget {
  const _ToggleTile({
    required this.icon,
    required this.tint,
    required this.fg,
    required this.label,
    required this.value,
    required this.onChanged,
  });

  final IconData icon;
  final Color tint;
  final Color fg;
  final String label;
  final bool value;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () => onChanged(!value),
      child: Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: AppSpacing.lg,
          vertical: AppSpacing.sm,
        ),
        child: Row(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: tint,
                borderRadius: BorderRadius.circular(AppRadius.sm),
              ),
              child: Icon(icon, color: fg, size: 18),
            ),
            const SizedBox(width: AppSpacing.md),
            Expanded(
              child: Text(
                label,
                style: AppTypography.bodyLg.copyWith(
                  color: AppColors.textPrimary,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
            Switch.adaptive(
              value: value,
              onChanged: onChanged,
              activeThumbColor: AppColors.primary,
            ),
          ],
        ),
      ),
    );
  }
}

class _Divider extends StatelessWidget {
  const _Divider();
  @override
  Widget build(BuildContext context) {
    return const Padding(
      padding: EdgeInsets.symmetric(horizontal: AppSpacing.lg),
      child: Divider(height: 1, thickness: 1, color: AppColors.outline),
    );
  }
}

class _SignOutButton extends StatelessWidget {
  const _SignOutButton({required this.onTap});
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(AppRadius.lg),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(
          horizontal: AppSpacing.lg,
          vertical: AppSpacing.lg,
        ),
        decoration: BoxDecoration(
          color: AppColors.tintRed,
          borderRadius: BorderRadius.circular(AppRadius.lg),
          border: Border.all(
              color: AppColors.danger.withValues(alpha: 0.18)),
        ),
        child: Row(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: AppColors.danger.withValues(alpha: 0.10),
                borderRadius: BorderRadius.circular(AppRadius.sm),
              ),
              child: const Icon(Icons.logout_rounded,
                  color: AppColors.danger, size: 18),
            ),
            const SizedBox(width: AppSpacing.md),
            Expanded(
              child: Text(
                'Sign out',
                style: AppTypography.bodyLg.copyWith(
                  color: AppColors.danger,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
            const Icon(Icons.chevron_right_rounded,
                color: AppColors.danger, size: 20),
          ],
        ),
      ),
    );
  }
}

class _IconChip extends StatelessWidget {
  const _IconChip({required this.icon, required this.onTap});
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(99),
      onTap: onTap,
      child: Container(
        width: 40,
        height: 40,
        decoration: BoxDecoration(
          color: Colors.white,
          shape: BoxShape.circle,
          border: Border.all(color: AppColors.outline),
          boxShadow: AppShadows.card,
        ),
        child: Icon(icon, color: AppColors.textPrimary, size: 18),
      ),
    );
  }
}
