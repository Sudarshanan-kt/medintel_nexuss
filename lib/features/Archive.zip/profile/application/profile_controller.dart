import 'dart:convert';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import '../../../core/network/dio_client.dart';
import '../domain/profile_record.dart';

/// In-memory + secure-storage-backed profile state.
class ProfileController extends Notifier<ProfileRecord> {
  static const _kAllergies = 'mn_profile_allergies';
  static const _kConditions = 'mn_profile_conditions';
  static const _kContacts = 'mn_profile_contacts';
  static const _kBiometric = 'mn_profile_biometric';
  static const _kNotifications = 'mn_profile_notifications';
  static const _kLanguage = 'mn_profile_language';

  FlutterSecureStorage get _storage => ref.read(secureStorageProvider);

  @override
  ProfileRecord build() {
    // Async hydrate; until storage answers, render initial state so the UI
    // never blanks.
    Future.microtask(_hydrate);
    return ProfileRecord.initial;
  }

  Future<void> _hydrate() async {
    try {
      final allergiesRaw = await _storage.read(key: _kAllergies);
      final conditionsRaw = await _storage.read(key: _kConditions);
      final contactsRaw = await _storage.read(key: _kContacts);
      final biometricRaw = await _storage.read(key: _kBiometric);
      final notificationsRaw = await _storage.read(key: _kNotifications);
      final languageRaw = await _storage.read(key: _kLanguage);

      state = ProfileRecord(
        allergies: allergiesRaw != null
            ? (jsonDecode(allergiesRaw) as List).cast<String>()
            : state.allergies,
        conditions: conditionsRaw != null
            ? (jsonDecode(conditionsRaw) as List).cast<String>()
            : state.conditions,
        emergencyContacts: contactsRaw != null
            ? (jsonDecode(contactsRaw) as List)
                .map((e) =>
                    EmergencyContact.fromJson(e as Map<String, dynamic>))
                .toList()
            : state.emergencyContacts,
        biometricEnabled: biometricRaw != null
            ? biometricRaw == 'true'
            : state.biometricEnabled,
        notifications: notificationsRaw != null
            ? NotificationLevel.values.byName(notificationsRaw)
            : state.notifications,
        language: languageRaw != null
            ? AppLanguage.fromCode(languageRaw)
            : state.language,
      );
    } catch (_) {/* ignore hydrate errors — fall back to initial */}
  }

  // ── Allergies ────────────────────────────────────────────────────────
  Future<void> setAllergies(List<String> next) async {
    state = state.copyWith(allergies: List.unmodifiable(next));
    await _storage.write(key: _kAllergies, value: jsonEncode(next));
  }

  // ── Conditions ───────────────────────────────────────────────────────
  Future<void> setConditions(List<String> next) async {
    state = state.copyWith(conditions: List.unmodifiable(next));
    await _storage.write(key: _kConditions, value: jsonEncode(next));
  }

  // ── Emergency contacts ───────────────────────────────────────────────
  Future<void> addEmergencyContact(EmergencyContact c) async {
    final next = [...state.emergencyContacts, c];
    state = state.copyWith(emergencyContacts: next);
    await _persistContacts();
  }

  Future<void> updateEmergencyContact(EmergencyContact c) async {
    final next = [
      for (final existing in state.emergencyContacts)
        if (existing.id == c.id) c else existing,
    ];
    state = state.copyWith(emergencyContacts: next);
    await _persistContacts();
  }

  Future<void> removeEmergencyContact(String id) async {
    final next =
        state.emergencyContacts.where((c) => c.id != id).toList();
    state = state.copyWith(emergencyContacts: next);
    await _persistContacts();
  }

  Future<void> _persistContacts() async {
    await _storage.write(
      key: _kContacts,
      value: jsonEncode(
        state.emergencyContacts.map((c) => c.toJson()).toList(),
      ),
    );
  }

  // ── Preferences ──────────────────────────────────────────────────────
  Future<void> setBiometric(bool enabled) async {
    state = state.copyWith(biometricEnabled: enabled);
    await _storage.write(key: _kBiometric, value: enabled.toString());
  }

  Future<void> setNotifications(NotificationLevel level) async {
    state = state.copyWith(notifications: level);
    await _storage.write(key: _kNotifications, value: level.name);
  }

  Future<void> setLanguage(AppLanguage lang) async {
    state = state.copyWith(language: lang);
    await _storage.write(key: _kLanguage, value: lang.code);
  }
}

final profileControllerProvider =
    NotifierProvider<ProfileController, ProfileRecord>(
  ProfileController.new,
);
